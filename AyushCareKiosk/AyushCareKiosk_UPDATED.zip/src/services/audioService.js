import { kioskApi } from './api';

/** Handles server-generated speech. Browser speech synthesis is deliberately not
 * used for clinical content because the backend/ML provider is the source of truth. */
export class AudioService {
  constructor(apiClient = kioskApi, AudioCtor = window.Audio) {
    this.api = apiClient;
    this.AudioCtor = AudioCtor;
    this.activeAudio = null;
  }

  stop() {
    if (this.activeAudio) {
      this.activeAudio.pause();
      this.activeAudio.currentTime = 0;
      this.activeAudio = null;
    }
  }

  async speak(sessionId, text, language) {
    if (!sessionId || !text) throw new Error('A session and text are required for speech.');
    const response = await this.api.tts(sessionId, text, language);
    const base64 = response?.audio_base64 || response?.audio?.base64;
    if (!base64) throw new Error('The speech service returned no audio.');

    const encoding = String(response?.encoding || '').toUpperCase();
    const mime = response?.mime_type || (encoding === 'WAV' ? 'audio/wav' : 'audio/mpeg');
    this.stop();
    const audio = new this.AudioCtor(`data:${mime};base64,${base64}`);
    this.activeAudio = audio;
    audio.onended = () => {
      if (this.activeAudio === audio) this.activeAudio = null;
    };
    await audio.play();
    return audio;
  }
}

export const audioService = new AudioService();
export default audioService;
