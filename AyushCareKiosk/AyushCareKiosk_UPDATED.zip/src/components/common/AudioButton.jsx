import React, { useEffect, useState } from 'react';
import { Volume2, VolumeX, Loader2 } from 'lucide-react';
import { audioService } from '../../services/audioService';
import { kioskApi, getErrorMessage } from '../../services/api';
import { useKioskStore } from '../../store/useKioskStore';

export default function AudioButton({ textToRead, label = 'Speak', className = '' }) {
  const { language, sessionData, audioEnabled } = useKioskStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => () => audioService.stop(), []);

  const speak = async () => {
    if (!audioEnabled || !textToRead || loading) return;
    setLoading(true);
    setError('');
    try {
      await audioService.speak(sessionData.consultationId, textToRead, language);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      type="button"
      className={`audio-btn ${className}`}
      onClick={speak}
      disabled={loading || !audioEnabled}
      title={error || undefined}
      aria-label={error || label}
    >
      {loading ? <Loader2 className="spin" size={16} /> : audioEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
      {label}
    </button>
  );
}
