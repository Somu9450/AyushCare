import React, { useEffect, useRef, useState } from 'react';
import { CheckCircle2, Loader2, RefreshCw, Smartphone, Clock3, ShieldCheck } from 'lucide-react';
import { kioskApi, getErrorMessage } from '../services/api';
import { useKioskStore } from '../store/useKioskStore';
import { useTranslation } from '../hooks/useTranslation';

const QR_SECONDS = 80;

export default function Screen8_QRUpload() {
  const { sessionData, updateSession, nextScreen } = useKioskStore();
  const { t } = useTranslation();
  const [qr, setQr] = useState(sessionData.patientUploadQr || null);
  const [docs, setDocs] = useState(sessionData.documents || []);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [seconds, setSeconds] = useState(QR_SECONDS);
  const advanced = useRef(false);
  const docsRef = useRef(docs);

  useEffect(() => { docsRef.current = docs; }, [docs]);

  const makeQr = async () => {
    if (!sessionData.consultationId) {
      setError('Clinical session is unavailable.');
      return;
    }
    setLoading(true); setError('');
    try {
      const data = await kioskApi.createPatientUploadQr(sessionData.consultationId);
      setQr(data);
      setSeconds(Math.min(QR_SECONDS, Number(data?.expires_in_seconds) || QR_SECONDS));
      advanced.current = false;
      updateSession({ patientUploadQr: data });
    } catch (e) {
      setError(getErrorMessage(e));
    } finally { setLoading(false); }
  };

  useEffect(() => { if (!qr) void makeQr(); }, []);

  const refreshDocs = async () => {
    if (!sessionData.consultationId) return;
    try {
      const state = await kioskApi.getSession(sessionData.consultationId);
      const list = Array.isArray(state?.documents) ? state.documents : [];
      setDocs(list);
      docsRef.current = list;
    } catch {}
  };

  useEffect(() => {
    if (!sessionData.consultationId) return;
    const timer = setInterval(refreshDocs, 2500);
    return () => clearInterval(timer);
  }, [sessionData.consultationId]);

  useEffect(() => {
    if (!qr) return;
    const timer = setInterval(() => {
      setSeconds((current) => {
        if (current <= 1) {
          clearInterval(timer);
          if (!advanced.current) {
            advanced.current = true;
            updateSession({ documents: docsRef.current, patientUploadQr: null });
            nextScreen();
          }
          return 0;
        }
        return current - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [qr, nextScreen, updateSession]);

  const continueNow = () => {
    if (advanced.current) return;
    advanced.current = true;
    updateSession({ documents: docsRef.current, patientUploadQr: null });
    nextScreen();
  };

  const mobileBase = import.meta.env.VITE_MOBILE_PAIR_URL || window.location.origin;
  const token = qr?.token || '';
  const qrUrl = token ? `${mobileBase.replace(/\/$/, '')}?qr_token=${encodeURIComponent(token)}` : '';
  const qrImage = qrUrl ? `https://quickchart.io/qr?size=280&text=${encodeURIComponent(qrUrl)}` : '';

  return (
    <section className="screen-card qr-screen">
      <div className="qr-timebar">
        <span><Clock3 size={18}/> Mobile document upload</span>
        <strong>{seconds}s</strong>
      </div>

      <p className="eyebrow">06 • {t('documents')}</p>
      <h2>{t('mobileUpload')}</h2>
      <p>Scan this QR with your phone to open your AyushCare account and upload prescriptions or reports.</p>

      <div className="qr-layout">
        <div className="qr-placeholder">
          {qrImage ? <img className="qr-image" src={qrImage} alt="Patient document upload QR code" /> : <Loader2 className="spin" size={32} />}
          <strong>{qr?.patient_code || 'Generating…'}</strong>
          <small>QR access expires automatically after 80 seconds.</small>
          <div className="qr-secure-note"><ShieldCheck size={16}/> Secure patient-account access</div>
        </div>

        <div className="document-panel">
          <div className="panel-title">
            <span>{t('documents')}</span>
            <button className="icon-button" onClick={refreshDocs}><RefreshCw size={17}/></button>
          </div>
          {docs.length === 0 ? <p className="muted">No documents uploaded yet.</p> : docs.map((d) => (
            <div className="doc-row" key={d.id}>
              <CheckCircle2 size={18}/><span>{d.document_type || d.file_path_hash?.split('/').pop() || 'Document'}</span><small>{d.status}</small>
            </div>
          ))}
          <button className="secondary-btn" onClick={makeQr} disabled={loading}>
            {loading ? <Loader2 className="spin"/> : <Smartphone size={18}/>} Generate new QR
          </button>
        </div>
      </div>

      <button className="primary-btn wide" onClick={continueNow}>
        {docs.length ? t('continue') : t('skip')}
      </button>
      {error && <div className="error-box">{error}</div>}
    </section>
  );
}
