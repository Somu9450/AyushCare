# AyushCare Kiosk Integration Update

## Provider architecture

The Kiosk calls the Node.js backend only. Dynamic clinical language, speech recognition and speech synthesis are server-side capabilities:

`Kiosk -> Node.js -> Python ML API -> Bhashini`

Azure credentials and Bhashini credentials are never required in the browser.

## Language changes

- Removed the hardcoded `INTERVIEW_LANGUAGES` list from the interview-language screen.
- Added a backend-driven language catalog via `GET /language/languages`.
- Language selection is synchronized to the Node consultation and therefore to the Python AI session.
- Static UI localization remains local; dynamic clinical questions are not hardcoded in the language selector.
- The existing 22-language localization files are retained for fixed UI labels/accessibility.

## Speaker/TTS

`AudioButton` now uses `AudioService`, which calls the Node TTS endpoint and plays the returned server-generated audio. Browser `speechSynthesis` fallback was removed so dynamic clinical speech cannot silently bypass the configured Bhashini pipeline.

## Microphone/ASR

`SpeechRecorder` encapsulates microphone permission, MediaRecorder lifecycle, 250ms data collection, stream cleanup and cancellation. The interview uses pointer events for reliable mouse/touch kiosk interaction and sends the recorded blob to Node -> Python -> Bhashini ASR.

## OOP/refactor

Introduced focused classes:

- `LanguageService` — backend language catalog and lookup/cache.
- `AudioService` — server TTS request, audio playback and cleanup.
- `SpeechRecorder` — microphone/MediaRecorder lifecycle.

React components remain functional components/hooks; OOP is used at the service/resource boundary rather than forcing classes into React rendering.

## Redundancy removed

- Duplicate hardcoded interview language list in `Screen3b_LanguageSelect`.
- Direct browser speech-synthesis fallback for clinical content.
- Duplicated microphone stream/chunk lifecycle from the symptom screen.
- Duplicate language registry usage in the language-selection UI.

## Validation

The source tree was inspected after edits. A local `npm run build` could not be completed in this environment because the dependency installation timed out and the local `vite` binary was unavailable. No claim of live Bhashini API testing is made.
