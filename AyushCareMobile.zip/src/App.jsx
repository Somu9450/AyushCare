import React, { useEffect } from "react";
import useMobileStore, { SCREENS } from "./store/useMobileStore";

import AuthScreen from "./pages/mobile/AuthScreen";
import M1_MobileHome from "./pages/mobile/M1_MobileHome";

import MyVisitsScreen from "./pages/mobile/MyVisitsScreen";
import VisitDetailsScreen from "./pages/mobile/VisitDetailsScreen";

import AppointmentsScreen from "./pages/mobile/AppointmentsScreen";

import RecordsScreen from "./pages/mobile/RecordsScreen";
import DocumentDetailsScreen from "./pages/mobile/DocumentDetailsScreen";

import MoreScreen from "./pages/mobile/MoreScreen";
import PrivacyScreen from "./pages/mobile/PrivacyScreen";
import ConsentDetailsScreen from "./pages/mobile/ConsentDetailsScreen";

import KioskConnectScreen from "./pages/mobile/KioskConnectScreen";
import KioskSessionDetailsScreen from "./pages/mobile/KioskSessionDetailsScreen";

import ProfileScreen from "./pages/mobile/ProfileScreen";
import SettingsScreen from "./pages/mobile/SettingsScreen";
import AboutScreen from "./pages/mobile/AboutScreen";

import M2_DocumentType from "./pages/mobile/M2_DocumentType";
import M3_DocumentCapture from "./pages/mobile/M3_DocumentCapture";
import M4_DocumentReview from "./pages/mobile/M4_DocumentReview";
import M5_DocumentAnalysis from "./pages/mobile/M5_DocumentAnalysis";
import M6_ExtractedInformation from "./pages/mobile/M6_ExtractedInformation";
import M7_MedicalTimeline from "./pages/mobile/M7_MedicalTimeline";
import M8_HealthSummary from "./pages/mobile/M8_HealthSummary";
import M9_InformationSent from "./pages/mobile/M9_InformationSent";

/* ========================================================================== */
/* APPLICATION GUARDS                                                         */
/* ========================================================================== */

const DOCUMENT_SCREENS = new Set([
  SCREENS.M2,
  SCREENS.M3,
  SCREENS.M4,
  SCREENS.M5,
  SCREENS.M6,
  SCREENS.M7,
  SCREENS.M8,
  SCREENS.M9,
]);

const SCREEN_COMPONENTS = {
  [SCREENS.AUTH]: AuthScreen,

  [SCREENS.M1]: M1_MobileHome,

  [SCREENS.VISITS]: MyVisitsScreen,
  [SCREENS.VISIT_DETAILS]: VisitDetailsScreen,

  [SCREENS.APPOINTMENTS]: AppointmentsScreen,

  [SCREENS.RECORDS]: RecordsScreen,
  [SCREENS.DOCUMENT_DETAILS]: DocumentDetailsScreen,

  [SCREENS.MORE]: MoreScreen,
  [SCREENS.PRIVACY]: PrivacyScreen,
  [SCREENS.CONSENT_DETAILS]: ConsentDetailsScreen,

  [SCREENS.KIOSK_CONNECT]: KioskConnectScreen,
  [SCREENS.KIOSK_SESSION]: KioskSessionDetailsScreen,

  [SCREENS.PROFILE]: ProfileScreen,
  [SCREENS.SETTINGS]: SettingsScreen,
  [SCREENS.ABOUT]: AboutScreen,

  [SCREENS.M2]: M2_DocumentType,
  [SCREENS.M3]: M3_DocumentCapture,
  [SCREENS.M4]: M4_DocumentReview,
  [SCREENS.M5]: M5_DocumentAnalysis,
  [SCREENS.M6]: M6_ExtractedInformation,
  [SCREENS.M7]: M7_MedicalTimeline,
  [SCREENS.M8]: M8_HealthSummary,
  [SCREENS.M9]: M9_InformationSent,
};

/* ========================================================================== */
/* APP                                                                        */
/* ========================================================================== */

function App() {
  const {
    currentScreen,
    isAuthenticated,
    accessibilitySettings,
    documentDraft,
    extractedData,
    kioskSession,
    setScreen,
  } = useMobileStore();

  /* ------------------------------------------------------------------------ */
  /* ACCESSIBILITY                                                            */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    if (typeof document === "undefined") {
      return;
    }

    const root = document.documentElement;

    const textSize =
      accessibilitySettings?.textSize ||
      "default";

    root.setAttribute(
      "data-text-size",
      textSize
    );

    if (
      accessibilitySettings?.highContrast
    ) {
      root.setAttribute(
        "data-high-contrast",
        "true"
      );
    } else {
      root.removeAttribute(
        "data-high-contrast"
      );
    }

    if (
      accessibilitySettings?.reduceMotion
    ) {
      root.setAttribute(
        "data-reduce-motion",
        "true"
      );
    } else {
      root.removeAttribute(
        "data-reduce-motion"
      );
    }
  }, [accessibilitySettings]);

  /* ------------------------------------------------------------------------ */
  /* AUTH GUARD                                                               */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    if (
      currentScreen !== SCREENS.AUTH &&
      !isAuthenticated
    ) {
      setScreen(SCREENS.AUTH);
    }
  }, [
    currentScreen,
    isAuthenticated,
    setScreen,
  ]);

  /* ------------------------------------------------------------------------ */
  /* DOCUMENT WORKFLOW GUARD                                                 */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    if (!isAuthenticated) {
      return;
    }

    if (
      !DOCUMENT_SCREENS.has(
        currentScreen
      )
    ) {
      return;
    }

    /*
     * M2 is allowed to start a fresh document.
     *
     * M3 onwards require at least a valid
     * document draft.
     */
    if (
      currentScreen !== SCREENS.M2 &&
      !documentDraft
    ) {
      setScreen(SCREENS.M2);
      return;
    }

    /*
     * M4 onwards require captured pages.
     */
    const pages =
      Array.isArray(
        documentDraft?.pages
      )
        ? documentDraft.pages
        : [];

    const captureRequiredScreens =
      new Set([
        SCREENS.M4,
        SCREENS.M5,
        SCREENS.M6,
        SCREENS.M7,
        SCREENS.M8,
        SCREENS.M9,
      ]);

    if (
      captureRequiredScreens.has(
        currentScreen
      ) &&
      pages.length === 0
    ) {
      setScreen(SCREENS.M3);
      return;
    }

    /*
     * M6+ normally require extraction.
     *
     * Do not block M5 because M5 itself
     * produces the extraction.
     */
    const extractionRequiredScreens =
      new Set([
        SCREENS.M6,
        SCREENS.M7,
        SCREENS.M8,
        SCREENS.M9,
      ]);

    const hasExtraction =
      Boolean(
        extractedData &&
        typeof extractedData ===
          "object"
      );

    if (
      extractionRequiredScreens.has(
        currentScreen
      ) &&
      !hasExtraction
    ) {
      setScreen(SCREENS.M5);
    }
  }, [
    currentScreen,
    isAuthenticated,
    documentDraft,
    extractedData,
    setScreen,
  ]);

  /* ------------------------------------------------------------------------ */
  /* SCREEN RENDERING                                                         */
  /* ------------------------------------------------------------------------ */

  const renderScreen = () => {
    /*
     * Authentication is always the first gate.
     */
    if (!isAuthenticated) {
      return <AuthScreen />;
    }

    const ScreenComponent =
      SCREEN_COMPONENTS[
        currentScreen
      ];

    if (!ScreenComponent) {
      return <M1_MobileHome />;
    }

    return <ScreenComponent />;
  };

  /* ------------------------------------------------------------------------ */
  /* ACCESSIBILITY CLASSES                                                    */
  /* ------------------------------------------------------------------------ */

  const textSizeClass =
    accessibilitySettings?.textSize ===
    "large"
      ? "text-size-large"
      : accessibilitySettings?.textSize ===
        "xlarge"
      ? "text-size-xlarge"
      : "";

  const highContrastClass =
    accessibilitySettings?.highContrast
      ? "theme-high-contrast"
      : "";

  const reduceMotionClass =
    accessibilitySettings?.reduceMotion
      ? "theme-reduce-motion"
      : "";

  /* ------------------------------------------------------------------------ */
  /* APP SHELL                                                                */
  /* ------------------------------------------------------------------------ */

  return (
    <div
      className={[
        "min-h-screen",
        "w-full",
        "bg-slate-50",
        "text-slate-900",
        "flex",
        "flex-col",
        "font-sans",
        "antialiased",
        textSizeClass,
        highContrastClass,
        reduceMotionClass,
      ]
        .filter(Boolean)
        .join(" ")}
      data-kiosk-connected={
        kioskSession?.status ===
        "CONNECTED"
          ? "true"
          : "false"
      }
    >
      <div className="flex-1 flex flex-col w-full">
        {renderScreen()}
      </div>
    </div>
  );
}

export default App;