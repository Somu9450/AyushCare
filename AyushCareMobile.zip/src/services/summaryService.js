import { mockHealthSummary, mockTimeline } from "../data/mockData";

const clone = (value) => {
  if (value === undefined || value === null) return value;

  try {
    return structuredClone(value);
  } catch {
    return JSON.parse(JSON.stringify(value));
  }
};

const safeArray = (value) => {
  if (Array.isArray(value)) return value;
  if (value === undefined || value === null) return [];
  return [value];
};

const firstNonEmpty = (...values) => {
  for (const value of values) {
    if (
      value !== undefined &&
      value !== null &&
      String(value).trim() !== ""
    ) {
      return value;
    }
  }

  return "";
};

const normalizeItem = (item) => {
  if (typeof item === "string") {
    return {
      name: item,
      label: item,
    };
  }

  if (!item || typeof item !== "object") {
    return {
      name: String(item ?? ""),
      label: String(item ?? ""),
    };
  }

  return {
    ...item,
    name: firstNonEmpty(
      item.name,
      item.test,
      item.testName,
      item.medicine,
      item.medication,
      item.diagnosis,
      item.label,
      item.value,
      "Information"
    ),
  };
};

const normalizeExtraction = (extracted) => {
  const source = extracted || {};

  const detected = source.detected_entities || source.detectedEntities || {};

  return {
    ...clone(source),

    parsedDate: firstNonEmpty(
      source.parsedDate,
      source.parsed_date,
      source.date,
      source.documentDate
    ),

    medicines: safeArray(
      firstNonEmpty(
        source.medicines,
        source.medications,
        detected.medicines
      )
    ).map(normalizeItem),

    diagnoses: safeArray(
      firstNonEmpty(
        source.diagnoses,
        source.conditions,
        detected.diagnoses
      )
    ).map(normalizeItem),

    investigations: safeArray(
      firstNonEmpty(
        source.investigations,
        source.tests,
        source.labResults,
        detected.investigations,
        detected.lab_results,
        detected.tests
      )
    ).map(normalizeItem),

    symptoms: safeArray(
      firstNonEmpty(
        source.symptoms,
        source.complaints,
        source.chiefComplaint,
        source.chief_complaint,
        detected.symptoms
      )
    ).map(normalizeItem),
  };
};

export async function fetchMedicalTimeline(patientId) {
  void patientId;

  await Promise.resolve();

  return clone(mockTimeline || []);
}

export async function fetchHealthSummary(patientId, context = {}) {
  void patientId;

  await Promise.resolve();

  const extracted = normalizeExtraction(
    context.extractedData || context.extraction
  );

  const base = clone(mockHealthSummary || {});

  const medicines = extracted.medicines.length
    ? extracted.medicines
    : safeArray(base.medicines).map(normalizeItem);

  const diagnoses = extracted.diagnoses.length
    ? extracted.diagnoses
    : safeArray(base.diagnoses).map(normalizeItem);

  const investigations = extracted.investigations.length
    ? extracted.investigations
    : safeArray(base.investigations).map(normalizeItem);

  const symptoms = extracted.symptoms.length
    ? extracted.symptoms
    : safeArray(base.symptoms).map(normalizeItem);

  const extractedDate = extracted.parsedDate;

  return {
    ...base,

    date: firstNonEmpty(base.date, extractedDate),

    medicines,
    diagnoses,
    investigations,
    symptoms,

    plainLanguage: firstNonEmpty(
      base.plainLanguage,
      base.patientSummary,
      base.summary,
      "Your uploaded health information has been organized for easier review."
    ),

    source: firstNonEmpty(
      base.source,
      extracted.documentType,
      "Uploaded medical document"
    ),

    extractionStatus: extractedDate || extracted.medicines.length
      ? "success"
      : firstNonEmpty(base.extractionStatus, "demo"),
  };
}

export function buildPatientHealthSummary({
  extractedData,
  existingSummary,
  timeline = [],
}) {
  const extracted = normalizeExtraction(extractedData);

  const base = existingSummary ? clone(existingSummary) : {};

  const hasExtractedData =
    extracted.medicines.length ||
    extracted.diagnoses.length ||
    extracted.investigations.length ||
    extracted.symptoms.length ||
    extracted.parsedDate;

  if (!hasExtractedData) {
    return {
      ...base,
      timeline: clone(timeline),
    };
  }

  const medicineText = extracted.medicines
    .map((item) => item.name)
    .filter(Boolean)
    .join(", ");

  const diagnosisText = extracted.diagnoses
    .map((item) => item.name)
    .filter(Boolean)
    .join(", ");

  const investigationText = extracted.investigations
    .map((item) => item.name)
    .filter(Boolean)
    .join(", ");

  const symptomText = extracted.symptoms
    .map((item) => item.name)
    .filter(Boolean)
    .join(", ");

  const sentences = [];

  if (symptomText) {
    sentences.push(`Reported symptoms include ${symptomText}.`);
  }

  if (diagnosisText) {
    sentences.push(
      `The uploaded document mentions ${diagnosisText}.`
    );
  }

  if (medicineText) {
    sentences.push(
      `Medicines mentioned include ${medicineText}.`
    );
  }

  if (investigationText) {
    sentences.push(
      `Investigations mentioned include ${investigationText}.`
    );
  }

  if (!sentences.length) {
    sentences.push(
      "Your uploaded information has been organized for review by your healthcare team."
    );
  }

  return {
    ...base,
    plainLanguage: sentences.join(" "),
    patientSummary: sentences.join(" "),
    summary: sentences.join(" "),

    date: firstNonEmpty(
      base.date,
      extracted.parsedDate
    ),

    medicines: extracted.medicines,
    diagnoses: extracted.diagnoses,
    investigations: extracted.investigations,
    symptoms: extracted.symptoms,

    timeline: clone(timeline),
    extractionStatus: "success",
  };
}

export function buildDoctorHandoffPayload({
  sessionId,
  patient,
  extractedData,
  timeline,
  healthSummary,
  visits,
  kioskSession,
}) {
  const normalizedExtraction = normalizeExtraction(extractedData);

  return {
    sessionId: sessionId || null,

    patient: patient
      ? {
          id: patient.id || patient.patientId || null,
          patientId: patient.patientId || patient.id || null,
          name: patient.name || patient.fullName || null,
          age: patient.age ?? null,
          gender: patient.gender || null,
        }
      : null,

    visit: {
      facility:
        kioskSession?.facilityName ||
        kioskSession?.facility ||
        null,

      kioskSessionId:
        kioskSession?.sessionId ||
        kioskSession?.id ||
        null,

      reference:
        kioskSession?.reference ||
        kioskSession?.sessionReference ||
        null,
    },

    extraction: normalizedExtraction,

    healthSummary: clone(healthSummary || {}),

    timeline: clone(timeline || []),

    visits: clone(visits || []),

    metadata: {
      generatedAt: new Date().toISOString(),
      source: "AyushCareMobile",
      prototype: true,
    },
  };
}

export async function sendSummaryToDoctor(sessionId, payload = {}) {
  await Promise.resolve();

  const handoffPayload = buildDoctorHandoffPayload({
    sessionId,
    ...payload,
  });

  /*
   * Prototype transport boundary.
   *
   * In production this function should POST handoffPayload to the backend
   * endpoint consumed by the doctor panel. Keeping the boundary here means
   * the mobile UI/store does not need to know the backend transport details.
   */
  return {
    success: true,
    status: "sent",
    sentAt: handoffPayload.metadata.generatedAt,
    sessionId: handoffPayload.sessionId,
    payload: handoffPayload,
  };
}

export default {
  fetchMedicalTimeline,
  fetchHealthSummary,
  buildPatientHealthSummary,
  buildDoctorHandoffPayload,
  sendSummaryToDoctor,
};