/**
 * Mobile Session Service
 *
 * Compatibility facade for session-related functionality.
 *
 * The mobile application has two different session concepts:
 *
 * 1. Patient authentication session
 *    - created after OTP login
 *
 * 2. Temporary kiosk session
 *    - created when the mobile app connects to a kiosk QR
 *
 * Keep these concepts separate.
 *
 * This file intentionally re-exports the kiosk functions so existing
 * screens can continue importing from mobileSessionService while the
 * actual implementation remains in kioskSessionService.
 */

export {
  DEFAULT_DEMO_TOKEN,
  parseKioskQrReference,
  connectKioskSession,
  validateKioskSession,
  disconnectKioskSession,
  endKioskSession,
  createDemoKioskSession,
  buildKioskQrValue,
  getDefaultDemoToken,
} from "./kioskSessionService.js";

/**
 * Create a lightweight mobile session object.
 *
 * This does not authenticate the patient.
 * Authentication belongs to authService.
 */
export function createMobileSession(user, authSession = {}) {
  return {
    user: user || null,

    sessionId:
      authSession.sessionId ||
      `mobile_${Date.now()}`,

    authenticatedAt:
      authSession.authenticatedAt ||
      new Date().toISOString(),

    status: "AUTHENTICATED",
  };
}

/**
 * Clear local mobile-session information.
 *
 * Actual backend logout belongs to authService.logoutPatient().
 */
export function clearMobileSession() {
  return {
    user: null,
    sessionId: null,
    authenticatedAt: null,
    status: "SIGNED_OUT",
  };
}