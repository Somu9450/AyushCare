/**
 * Kiosk Session Service
 *
 * Responsible for the temporary connection between:
 *
 *   Kiosk -> QR -> Mobile
 *
 * The QR contains only a short-lived session reference.
 * Medical information is never encoded into the QR payload.
 *
 * Current implementation:
 * - local mock session registry
 * - simulated async connection latency
 *
 * Production implementation:
 * - backend-issued short-lived session token
 * - server-side session validation
 * - authenticated kiosk/mobile APIs
 */

const SESSION_TTL_SECONDS = 15 * 60;

/**
 * Backwards-compatible demo token.
 *
 * Existing screens import this constant, so keep it as part
 * of the public service API.
 */
export const DEFAULT_DEMO_TOKEN = "AYUSH-DEMO-42";

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const MOCK_KIOSK_SESSIONS = {
  "AYUSH-DEMO-42": {
    sessionId: "kiosk_sess_42",
    sessionReference: "AYUSH-DEMO-42",
    token: "mock_kiosk_token_42",
    facility: "Civil Hospital OPD",
    department: "General OPD",
    location: "New Delhi",
    kioskNumber: "K-04",
    queueToken: "#45",
    servingToken: "#42",
    patientId: "PATIENT-001",
    patientName: "Rajesh Kumar Sharma",
    createdAt: "2026-09-01T09:30:00.000Z",
    expiresAt: "2026-12-31T23:59:59.000Z",
  },

  "AYUSH-DEMO-45": {
    sessionId: "kiosk_sess_45",
    sessionReference: "AYUSH-DEMO-45",
    token: "mock_kiosk_token_45",
    facility: "Civil Hospital OPD",
    department: "General OPD",
    location: "New Delhi",
    kioskNumber: "K-05",
    queueToken: "#48",
    servingToken: "#46",
    patientId: "PATIENT-001",
    patientName: "Rajesh Kumar Sharma",
    createdAt: "2026-09-01T10:00:00.000Z",
    expiresAt: "2026-12-31T23:59:59.000Z",
  },
};

function clone(value) {
  if (value === undefined || value === null) {
    return value;
  }

  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return value;
  }
}

function normalizeReference(reference) {
  return String(reference || "")
    .trim()
    .replace(/^.*(?:session|ref|token)=/i, "");
}

function createMockReference() {
  return `AYUSH-${Date.now().toString(36).toUpperCase()}`;
}

/**
 * Parse a kiosk QR value.
 *
 * Supported:
 *
 * AYUSH-DEMO-42
 * ?session=AYUSH-DEMO-42
 * ?sessionRef=AYUSH-DEMO-42
 * ?token=AYUSH-DEMO-42
 * https://example.com/?session=AYUSH-DEMO-42
 */
export function parseKioskQrReference(input) {
  const value = String(input || "").trim();

  if (!value) {
    return null;
  }

  try {
    if (
      value.startsWith("http://") ||
      value.startsWith("https://")
    ) {
      const url = new URL(value);

      return (
        url.searchParams.get("session") ||
        url.searchParams.get("sessionRef") ||
        url.searchParams.get("token") ||
        url.searchParams.get("ref") ||
        null
      );
    }
  } catch {
    // Continue with plain-reference parsing.
  }

  const match = value.match(
    /(?:session|sessionRef|token|ref)=([^&\s]+)/i,
  );

  if (match?.[1]) {
    try {
      return decodeURIComponent(match[1]);
    } catch {
      return match[1];
    }
  }

  return value;
}

/**
 * Connect mobile to kiosk.
 *
 * Production API:
 * POST /api/v1/mobile/kiosk/connect
 *
 * Body:
 * {
 *   sessionReference
 * }
 */
export async function connectKioskSession(sessionReference) {
  await wait(450);

  const parsedReference =
    parseKioskQrReference(sessionReference);

  if (!parsedReference) {
    return {
      success: false,
      error: "No kiosk session reference was provided.",
    };
  }

  const normalizedReference =
    normalizeReference(parsedReference);

  const existingSession =
    MOCK_KIOSK_SESSIONS[normalizedReference];

  if (!existingSession) {
    return {
      success: false,
      error:
        "This kiosk session is invalid or has expired. Please scan the current QR code again.",
    };
  }

  return {
    success: true,

    session: {
      ...clone(existingSession),

      status: "CONNECTED",

      connectedAt: new Date().toISOString(),

      expiresAt:
        existingSession.expiresAt ||
        new Date(
          Date.now() +
            SESSION_TTL_SECONDS * 1000,
        ).toISOString(),
    },
  };
}

/**
 * Validate an existing kiosk session.
 *
 * Production API:
 * GET /api/v1/mobile/kiosk/session/:sessionId
 */
export async function validateKioskSession(sessionId) {
  await wait(150);

  const session = Object.values(
    MOCK_KIOSK_SESSIONS,
  ).find(
    (item) => item.sessionId === sessionId,
  );

  if (!session) {
    return {
      success: false,
      valid: false,
      error: "Kiosk session not found.",
    };
  }

  return {
    success: true,
    valid: true,

    session: {
      ...clone(session),
      status: "CONNECTED",
    },
  };
}

/**
 * Disconnect only the mobile device.
 *
 * The kiosk session itself may remain active.
 *
 * Production API:
 * POST /api/v1/mobile/kiosk/disconnect
 */
export async function disconnectKioskSession(
  sessionId,
) {
  await wait(150);

  return {
    success: true,
    sessionId: sessionId || null,
    disconnectedAt: new Date().toISOString(),
  };
}

/**
 * End the kiosk-side session.
 *
 * Production API:
 * POST /api/v1/kiosk/sessions/:sessionId/end
 */
export async function endKioskSession(sessionId) {
  await wait(150);

  return {
    success: true,
    sessionId: sessionId || null,
    status: "ENDED",
    endedAt: new Date().toISOString(),
  };
}

/**
 * Create a demo kiosk session.
 *
 * Useful for local testing.
 *
 * Production:
 * The kiosk backend should create a cryptographically
 * random short-lived reference.
 */
export function createDemoKioskSession() {
  const reference = createMockReference();

  return {
    sessionId: `kiosk_sess_${Date.now()}`,
    sessionReference: reference,
    qrValue: reference,
    expiresInSeconds: SESSION_TTL_SECONDS,
  };
}

/**
 * Build the QR payload.
 *
 * IMPORTANT:
 * Only the temporary session reference is included.
 * Patient medical information is NOT included.
 */
export function buildKioskQrValue(
  sessionReference,
) {
  const reference =
    normalizeReference(sessionReference);

  return `https://somu9450.github.io/AyushCare/?session=${encodeURIComponent(
    reference,
  )}`;
}

/**
 * Return the default demo session reference.
 *
 * Kept as a named helper for screens/tests that previously
 * relied on the demo token.
 */
export function getDefaultDemoToken() {
  return DEFAULT_DEMO_TOKEN;
}