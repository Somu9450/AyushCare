/**
 * Visit Service
 *
 * A visit represents an actual healthcare encounter.
 *
 * Appointment:
 *   planned consultation
 *
 * Visit:
 *   actual encounter
 *
 * Documents can be associated with a visit.
 */

import { mockVisits } from "../data/mockData.js";

const wait = (ms) =>
  new Promise((resolve) => setTimeout(resolve, ms));

const clone = (value) => {
  if (value === undefined || value === null) {
    return value;
  }

  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return value;
  }
};

function getVisitList() {
  if (Array.isArray(mockVisits)) {
    return mockVisits;
  }

  if (
    Array.isArray(mockVisits?.all)
  ) {
    return mockVisits.all;
  }

  return [
    ...(Array.isArray(
      mockVisits?.upcoming,
    )
      ? mockVisits.upcoming
      : []),

    ...(Array.isArray(
      mockVisits?.past,
    )
      ? mockVisits.past
      : []),
  ];
}

function matchesVisitId(
  visit,
  visitId,
) {
  const target = String(
    visitId || "",
  ).trim();

  if (!target) {
    return false;
  }

  return (
    String(visit?.id || "") === target ||
    String(
      visit?.visitId || "",
    ) === target
  );
}

/**
 * Fetch all visits.
 */
export async function fetchVisits(
  patientId,
) {
  await wait(150);

  return {
    success: true,
    patientId: patientId || null,
    visits: clone(
      getVisitList(),
    ),
  };
}

/**
 * Fetch one visit.
 */
export async function fetchVisitDetails(
  visitId,
) {
  await wait(120);

  const visit =
    getVisitList().find(
      (item) =>
        matchesVisitId(
          item,
          visitId,
        ),
    ) || null;

  if (!visit) {
    return {
      success: false,
      visit: null,
      error: "Visit not found.",
    };
  }

  return {
    success: true,
    visit: clone(visit),
  };
}

/**
 * Fetch completed/past visits.
 */
export async function fetchPastVisits(
  patientId,
) {
  await wait(150);

  const visits =
    getVisitList().filter(
      (visit) => {
        const status = String(
          visit?.status || "",
        ).toLowerCase();

        return (
          status === "completed" ||
          status === "past" ||
          status === "closed" ||
          status === "finished"
        );
      },
    );

  return {
    success: true,
    patientId: patientId || null,
    visits: clone(visits),
  };
}

/**
 * Fetch currently active visit.
 */
export async function fetchActiveVisit(
  patientId,
) {
  await wait(150);

  const visit =
    getVisitList().find(
      (item) => {
        const status = String(
          item?.status || "",
        ).toLowerCase();

        return (
          status === "active" ||
          status === "in_progress" ||
          status === "waiting" ||
          status === "current"
        );
      },
    ) || null;

  return {
    success: true,
    patientId: patientId || null,
    visit: clone(visit),
  };
}

/**
 * Attach a document to a visit.
 *
 * Production API:
 * POST /api/v1/mobile/visits/:visitId/documents
 */
export async function attachDocumentToVisit(
  visitId,
  documentId,
) {
  await wait(120);

  if (!visitId) {
    return {
      success: false,
      error: "Visit ID is required.",
    };
  }

  if (!documentId) {
    return {
      success: false,
      error: "Document ID is required.",
    };
  }

  return {
    success: true,
    visitId: String(visitId),
    documentId: String(documentId),
    attachedAt:
      new Date().toISOString(),
  };
}

/**
 * Return documents linked to a particular visit.
 */
export function getDocumentsForVisit(
  visitId,
  records = [],
) {
  if (!visitId) {
    return [];
  }

  return records.filter(
    (record) =>
      String(
        record?.visitId || "",
      ) === String(visitId) ||
      String(
        record?.associatedVisitId || "",
      ) === String(visitId),
  );
}