/**
 * Appointment Service
 *
 * Handles scheduled and historical appointments.
 *
 * Appointment = planned/scheduled consultation.
 * Visit       = actual healthcare encounter.
 *
 * Current implementation uses local mock data.
 * Production implementation should use authenticated hospital APIs.
 */

import { mockAppointments } from "../data/mockData.js";

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function clone(value) {
  if (value === undefined || value === null) return value;

  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return value;
  }
}

function getAllAppointments() {
  return [
    mockAppointments?.today,
    ...(mockAppointments?.upcoming || []),
    ...(mockAppointments?.past || []),
  ].filter(Boolean);
}

/**
 * Fetch today's active appointment.
 *
 * Production API:
 * GET /api/v1/mobile/appointments/today?patientId=...
 */
export async function fetchTodayAppointment(patientId) {
  await wait(150);

  return {
    success: true,
    patientId: patientId || null,
    appointment: clone(mockAppointments?.today || null),
  };
}

/**
 * Fetch upcoming appointments.
 *
 * Production API:
 * GET /api/v1/mobile/appointments/upcoming?patientId=...
 */
export async function fetchUpcomingAppointments(patientId) {
  await wait(150);

  return {
    success: true,
    patientId: patientId || null,
    appointments: clone(mockAppointments?.upcoming || []),
  };
}

/**
 * Fetch historical appointments.
 *
 * Production API:
 * GET /api/v1/mobile/appointments/past?patientId=...
 */
export async function fetchPastAppointments(patientId) {
  await wait(150);

  return {
    success: true,
    patientId: patientId || null,
    appointments: clone(mockAppointments?.past || []),
  };
}

/**
 * Fetch one appointment by ID.
 *
 * Production API:
 * GET /api/v1/mobile/appointments/:appointmentId
 */
export async function fetchAppointmentDetails(appointmentId) {
  await wait(100);

  const normalizedId = String(appointmentId || "").trim();

  const appointment =
    getAllAppointments().find(
      (item) => String(item.id) === normalizedId,
    ) || null;

  return {
    success: Boolean(appointment),
    appointment: clone(appointment),
  };
}