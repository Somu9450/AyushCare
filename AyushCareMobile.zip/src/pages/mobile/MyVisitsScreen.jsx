import React, { useMemo } from "react";
import {
  ArrowLeft,
  CalendarDays,
  ChevronRight,
  Hospital,
  Stethoscope,
} from "lucide-react";

import useMobileStore from "../../store/useMobileStore";

export default function MyVisitsScreen() {
  const {
    visits,
    setSelectedVisit,
    setScreen,
  } = useMobileStore();

  const visitList = useMemo(() => {
    if (Array.isArray(visits)) {
      return visits;
    }

    if (Array.isArray(visits?.all)) {
      return visits.all;
    }

    return [
      ...(Array.isArray(visits?.past)
        ? visits.past
        : []),

      ...(Array.isArray(visits?.upcoming)
        ? visits.upcoming
        : []),
    ];
  }, [visits]);

  const sortedVisits = useMemo(() => {
    return [...visitList].sort(
      (a, b) => {
        const dateA = new Date(
          a?.date ||
            a?.visitDate ||
            a?.appointmentDate ||
            0,
        ).getTime();

        const dateB = new Date(
          b?.date ||
            b?.visitDate ||
            b?.appointmentDate ||
            0,
        ).getTime();

        return dateB - dateA;
      },
    );
  }, [visitList]);

  const openVisit = (visit) => {
    setSelectedVisit?.(visit);
    setScreen("VISIT_DETAILS");
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto min-h-screen w-full max-w-md">
        <header className="sticky top-0 z-10 flex items-center gap-3 border-b border-slate-200 bg-white px-5 py-4">
          <button
            type="button"
            onClick={() =>
              setScreen("MORE")
            }
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 active:scale-95"
            aria-label="Go back"
          >
            <ArrowLeft size={22} />
          </button>

          <div>
            <h1 className="text-lg font-bold">
              My Visits
            </h1>

            <p className="text-xs text-slate-500">
              Your healthcare history
            </p>
          </div>
        </header>

        <main className="px-5 py-6">
          {sortedVisits.length === 0 ? (
            <EmptyVisits />
          ) : (
            <div className="space-y-3">
              {sortedVisits.map(
                (visit, index) => (
                  <VisitCard
                    key={
                      visit?.id ||
                      visit?.visitId ||
                      `visit-${index}`
                    }
                    visit={visit}
                    onClick={() =>
                      openVisit(visit)
                    }
                  />
                ),
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

function VisitCard({
  visit,
  onClick,
}) {
  const doctor =
    visit?.doctor ||
    visit?.doctorName ||
    "Doctor";

  const department =
    visit?.department ||
    visit?.specialty ||
    "General OPD";

  const facility =
    visit?.facility ||
    visit?.hospital ||
    "Civil Hospital OPD";

  const date =
    visit?.date ||
    visit?.visitDate ||
    visit?.appointmentDate ||
    "Date unavailable";

  const status =
    visit?.status ||
    "Completed";

  const notes =
    visit?.summary ||
    visit?.reason ||
    visit?.chiefComplaint ||
    visit?.notes ||
    "";

  const normalizedStatus =
    String(status).toLowerCase();

  const isCompleted =
    normalizedStatus ===
      "completed" ||
    normalizedStatus ===
      "closed" ||
    normalizedStatus ===
      "finished" ||
    normalizedStatus ===
      "past";

  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full rounded-3xl border border-slate-100 bg-white p-5 text-left shadow-sm transition active:scale-[0.99]"
    >
      <div className="flex items-start gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-slate-100">
          <Hospital
            size={21}
            className="text-slate-600"
          />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h2 className="truncate text-sm font-bold">
                {department}
              </h2>

              <p className="mt-1 truncate text-xs text-slate-500">
                {doctor}
              </p>
            </div>

            <ChevronRight
              size={18}
              className="mt-1 shrink-0 text-slate-400"
            />
          </div>
        </div>
      </div>

      <div className="mt-4 flex items-center gap-2">
        <CalendarDays
          size={15}
          className="text-slate-400"
        />

        <span className="text-xs font-medium text-slate-600">
          {formatDate(date)}
        </span>

        <span
          className={`ml-auto rounded-full px-2.5 py-1 text-[11px] font-semibold ${
            isCompleted
              ? "bg-green-50 text-green-700"
              : "bg-blue-50 text-blue-700"
          }`}
        >
          {status}
        </span>
      </div>

      <div className="mt-3 flex items-center gap-2">
        <Stethoscope
          size={14}
          className="text-slate-400"
        />

        <span className="truncate text-xs text-slate-500">
          {facility}
        </span>
      </div>

      {notes && (
        <p className="mt-3 line-clamp-2 text-xs leading-5 text-slate-500">
          {notes}
        </p>
      )}
    </button>
  );
}

function formatDate(value) {
  if (!value) {
    return "Date unavailable";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return date.toLocaleDateString(
    "en-IN",
    {
      day: "numeric",
      month: "short",
      year: "numeric",
    },
  );
}

function EmptyVisits() {
  return (
    <div className="rounded-3xl border border-dashed border-slate-200 bg-white px-6 py-10 text-center">
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100">
        <CalendarDays
          size={26}
          className="text-slate-400"
        />
      </div>

      <h2 className="text-base font-bold">
        No visits yet
      </h2>

      <p className="mx-auto mt-2 max-w-xs text-sm leading-5 text-slate-500">
        Your completed healthcare visits will appear here.
      </p>
    </div>
  );
}