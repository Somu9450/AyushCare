import React, { useMemo } from "react";
import {
  ArrowLeft,
  CalendarDays,
  ChevronRight,
  FileText,
  Hospital,
  MapPin,
  Stethoscope,
} from "lucide-react";

import useMobileStore from "../../store/useMobileStore";

export default function VisitDetailsScreen() {
  const {
    selectedVisit,
    medicalRecords,
    setScreen,
  } = useMobileStore();

  const visit = selectedVisit || {};

  const linkedRecords = useMemo(() => {
    if (!Array.isArray(medicalRecords)) {
      return [];
    }

    const visitId =
      visit.id ||
      visit.visitId;

    if (!visitId) {
      return [];
    }

    return medicalRecords.filter(
      (record) =>
        String(
          record?.visitId || "",
        ) === String(visitId) ||
        String(
          record?.associatedVisitId ||
            "",
        ) === String(visitId),
    );
  }, [
    medicalRecords,
    visit,
  ]);

  const doctor =
    visit.doctor ||
    visit.doctorName ||
    "Doctor";

  const department =
    visit.department ||
    visit.specialty ||
    "General OPD";

  const facility =
    visit.facility ||
    visit.hospital ||
    "Civil Hospital OPD";

  const location =
    visit.location ||
    "New Delhi";

  const date =
    visit.date ||
    visit.visitDate ||
    visit.appointmentDate ||
    "";

  const summary =
    visit.summary ||
    visit.reason ||
    visit.chiefComplaint ||
    visit.notes ||
    "No visit summary available.";

  const goBack = () => {
    setScreen("VISITS");
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto min-h-screen w-full max-w-md">
        <header className="sticky top-0 z-10 flex items-center gap-3 border-b border-slate-200 bg-white px-5 py-4">
          <button
            type="button"
            onClick={goBack}
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 active:scale-95"
            aria-label="Go back"
          >
            <ArrowLeft size={22} />
          </button>

          <div>
            <h1 className="text-lg font-bold">
              Visit Details
            </h1>

            <p className="text-xs text-slate-500">
              Healthcare encounter
            </p>
          </div>
        </header>

        <main className="px-5 py-6">
          {/* Visit header */}
          <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div className="flex items-start gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-blue-50">
                <Stethoscope
                  size={23}
                  className="text-blue-600"
                />
              </div>

              <div className="min-w-0">
                <h2 className="text-base font-bold">
                  {department}
                </h2>

                <p className="mt-1 text-sm text-slate-500">
                  {doctor}
                </p>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3">
              <InfoTile
                icon={CalendarDays}
                label="Date"
                value={
                  formatDate(date)
                }
              />

              <InfoTile
                icon={Hospital}
                label="Facility"
                value={facility}
              />
            </div>

            <div className="mt-3 flex items-center gap-2 rounded-2xl bg-slate-50 px-3 py-3">
              <MapPin
                size={16}
                className="shrink-0 text-slate-400"
              />

              <span className="truncate text-xs font-medium text-slate-600">
                {location}
              </span>
            </div>
          </section>

          {/* Summary */}
          <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <h2 className="mb-3 text-sm font-bold">
              Visit Summary
            </h2>

            <p className="text-sm leading-6 text-slate-600">
              {summary}
            </p>
          </section>

          {/* Notes */}
          {(visit.notes ||
            visit.doctorNotes ||
            visit.clinicalNotes) && (
            <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
              <h2 className="mb-3 text-sm font-bold">
                Clinical Notes
              </h2>

              <p className="text-sm leading-6 text-slate-600">
                {visit.notes ||
                  visit.doctorNotes ||
                  visit.clinicalNotes}
              </p>
            </section>
          )}

          {/* Linked records */}
          <section className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold">
                  Linked Records
                </h2>

                <p className="mt-1 text-xs text-slate-400">
                  Documents associated with this visit
                </p>
              </div>

              <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
                {linkedRecords.length}
              </span>
            </div>

            {linkedRecords.length > 0 ? (
              <div className="space-y-2">
                {linkedRecords.map(
                  (record, index) => (
                    <button
                      key={
                        record.id ||
                        record.documentId ||
                        `record-${index}`
                      }
                      type="button"
                      onClick={() =>
                        setScreen(
                          "DOCUMENT_DETAILS",
                        )
                      }
                      className="flex w-full items-center gap-3 rounded-2xl border border-slate-100 p-3 text-left transition active:scale-[0.99]"
                    >
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-50">
                        <FileText
                          size={18}
                          className="text-slate-600"
                        />
                      </div>

                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">
                          {record.title ||
                            record.name ||
                            record.documentTitle ||
                            "Medical Document"}
                        </p>

                        <p className="mt-1 text-xs text-slate-400">
                          {record.type ||
                            "Medical record"}
                        </p>
                      </div>

                      <ChevronRight
                        size={17}
                        className="shrink-0 text-slate-400"
                      />
                    </button>
                  ),
                )}
              </div>
            ) : (
              <div className="rounded-2xl bg-slate-50 px-4 py-5 text-center">
                <FileText
                  size={24}
                  className="mx-auto mb-2 text-slate-300"
                />

                <p className="text-xs text-slate-500">
                  No documents are linked to this visit.
                </p>
              </div>
            )}
          </section>
        </main>
      </div>
    </div>
  );
}

function InfoTile({
  icon: Icon,
  label,
  value,
}) {
  return (
    <div className="rounded-2xl bg-slate-50 px-3 py-3">
      <div className="mb-1.5 flex items-center gap-1.5 text-slate-400">
        <Icon size={13} />
        <span className="text-[11px]">
          {label}
        </span>
      </div>

      <p className="truncate text-xs font-semibold text-slate-700">
        {value}
      </p>
    </div>
  );
}

function formatDate(value) {
  if (!value) {
    return "Date unavailable";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return date.toLocaleDateString(
    "en-IN",
    {
      day: "numeric",
      month: "short",
      year: "numeric",
    },
  );
}