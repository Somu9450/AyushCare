import React, { useState } from "react";
import {
  ArrowLeft,
  CheckCircle2,
  Clock3,
  Copy,
  Hospital,
  LogOut,
  MapPin,
  ShieldCheck,
  Smartphone,
  Unplug,
  Wifi,
} from "lucide-react";

import {
  disconnectKioskSession,
  endKioskSession,
} from "../../services/kioskSessionService";

export default function KioskSessionDetailsScreen({
  kioskSession,
  onBack,
  onDisconnected,
}) {
  const [isDisconnecting, setIsDisconnecting] =
    useState(false);

  const [copied, setCopied] = useState(false);

  const session = kioskSession || {};

  const isConnected =
    String(session.status || "").toUpperCase() ===
    "CONNECTED";

  const facility =
    session.facility || "Civil Hospital OPD";

  const department =
    session.department || "General OPD";

  const location =
    session.location || "New Delhi";

  const reference =
    session.sessionReference ||
    session.reference ||
    "—";

  const connectedAt =
    session.connectedAt ||
    session.createdAt ||
    null;

  const formatDateTime = (value) => {
    if (!value) {
      return "Not available";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return "Not available";
    }

    return date.toLocaleString("en-IN", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  const handleCopyReference = async () => {
    if (!reference || reference === "—") {
      return;
    }

    try {
      await navigator.clipboard.writeText(
        reference,
      );

      setCopied(true);

      window.setTimeout(() => {
        setCopied(false);
      }, 1500);
    } catch {
      // Clipboard access can be unavailable in some browsers.
    }
  };

  const handleDisconnect = async () => {
    if (isDisconnecting) {
      return;
    }

    setIsDisconnecting(true);

    try {
      if (session.sessionId) {
        await disconnectKioskSession(
          session.sessionId,
        );

        await endKioskSession(
          session.sessionId,
        );
      }

      if (typeof onDisconnected === "function") {
        onDisconnected();
      }
    } catch (error) {
      console.error(
        "Failed to disconnect kiosk:",
        error,
      );
    } finally {
      setIsDisconnecting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto flex min-h-screen w-full max-w-md flex-col">
        {/* Header */}
        <header className="flex items-center gap-3 border-b border-slate-200 bg-white px-5 py-4">
          <button
            type="button"
            onClick={onBack}
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 transition active:scale-95"
            aria-label="Go back"
          >
            <ArrowLeft size={22} />
          </button>

          <div>
            <h1 className="text-lg font-bold">
              Kiosk Session
            </h1>

            <p className="text-xs text-slate-500">
              Connection details
            </p>
          </div>
        </header>

        <main className="flex-1 px-5 py-6">
          {/* Connection status */}
          <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div className="flex items-center gap-4">
              <div
                className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
                  isConnected
                    ? "bg-green-50"
                    : "bg-slate-100"
                }`}
              >
                {isConnected ? (
                  <Wifi
                    size={26}
                    className="text-green-600"
                  />
                ) : (
                  <Unplug
                    size={26}
                    className="text-slate-500"
                  />
                )}
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold">
                    {isConnected
                      ? "Connected"
                      : "Disconnected"}
                  </h2>

                  {isConnected && (
                    <CheckCircle2
                      size={18}
                      className="text-green-600"
                    />
                  )}
                </div>

                <p className="mt-1 text-sm text-slate-500">
                  {isConnected
                    ? "This phone is linked to the active kiosk session."
                    : "This phone is no longer connected to the kiosk."}
                </p>
              </div>
            </div>
          </section>

          {/* Facility */}
          <section className="mb-5 overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-100">
            <div className="border-b border-slate-100 px-5 py-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                Healthcare facility
              </p>
            </div>

            <div className="space-y-0">
              <InfoRow
                icon={Hospital}
                label="Facility"
                value={facility}
              />

              <InfoRow
                icon={Smartphone}
                label="Department"
                value={department}
              />

              <InfoRow
                icon={MapPin}
                label="Location"
                value={location}
              />

              <InfoRow
                icon={Clock3}
                label="Connected"
                value={formatDateTime(
                  connectedAt,
                )}
                last
              />
            </div>
          </section>

          {/* Session reference */}
          <section className="mb-5 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div className="mb-3 flex items-center gap-2">
              <ShieldCheck
                size={18}
                className="text-blue-600"
              />

              <h3 className="text-sm font-bold">
                Session reference
              </h3>
            </div>

            <div className="flex items-center gap-2 rounded-2xl bg-slate-50 p-3">
              <code className="min-w-0 flex-1 break-all text-xs font-semibold text-slate-700">
                {reference}
              </code>

              <button
                type="button"
                onClick={handleCopyReference}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-slate-600 shadow-sm transition active:scale-95"
                aria-label="Copy session reference"
              >
                <Copy size={16} />
              </button>
            </div>

            {copied && (
              <p className="mt-2 text-xs font-medium text-green-600">
                Session reference copied.
              </p>
            )}

            <p className="mt-3 text-xs leading-5 text-slate-400">
              This reference identifies the temporary kiosk
              connection. Medical information is not stored
              inside the QR/session reference.
            </p>
          </section>

          {/* Privacy */}
          <section className="mb-6 rounded-3xl border border-blue-100 bg-blue-50 p-5">
            <div className="flex gap-3">
              <ShieldCheck
                size={21}
                className="mt-0.5 shrink-0 text-blue-600"
              />

              <div>
                <p className="text-sm font-semibold text-blue-950">
                  Privacy reminder
                </p>

                <p className="mt-1 text-xs leading-5 text-blue-800">
                  Disconnecting this phone ends its connection
                  to the kiosk. Your saved health records remain
                  under your account and are not deleted by
                  disconnecting.
                </p>
              </div>
            </div>
          </section>

          {/* Action */}
          {isConnected && (
            <button
              type="button"
              onClick={handleDisconnect}
              disabled={isDisconnecting}
              className="flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl border border-red-200 bg-white px-5 py-3.5 text-sm font-semibold text-red-600 transition hover:bg-red-50 active:scale-[0.99] disabled:opacity-50"
            >
              <LogOut size={18} />

              {isDisconnecting
                ? "Disconnecting…"
                : "Disconnect from Kiosk"}
            </button>
          )}
        </main>
      </div>
    </div>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
  last = false,
}) {
  return (
    <div
      className={`flex items-center gap-3 px-5 py-4 ${
        !last
          ? "border-b border-slate-100"
          : ""
      }`}
    >
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-50">
        <Icon
          size={17}
          className="text-slate-500"
        />
      </div>

      <div className="min-w-0 flex-1">
        <p className="text-xs text-slate-400">
          {label}
        </p>

        <p className="mt-0.5 truncate text-sm font-semibold text-slate-800">
          {value}
        </p>
      </div>
    </div>
  );
}