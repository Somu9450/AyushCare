import React from "react";
import {
  ArrowLeft,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock3,
  Building2,
  CalendarDays,
  AlertCircle,
  RotateCcw,
  Ban,
} from "lucide-react";

import useMobileStore from "../../store/useMobileStore";
import MobileHeader from "../../components/mobile/MobileHeader";
import BottomNavBar from "../../components/mobile/BottomNavBar";
import useLanguage from "../../i18n/translations";

const getConsentId = (consent) =>
  consent?.id ||
  consent?.consentId ||
  consent?.referenceId ||
  null;

const isConsentActive = (consent) =>
  consent?.status === "ACTIVE" ||
  consent?.status === "GRANTED" ||
  consent?.active === true;

const getConsentTitle = (consent, isHindi) =>
  isHindi
    ? consent?.hindiTitle ||
      consent?.title ||
      "डेटा सहमति"
    : consent?.title || "Data Consent";

const getConsentDescription = (consent, isHindi) =>
  isHindi
    ? consent?.hindiDescription ||
      consent?.description ||
      "स्वास्थ्य जानकारी के उपयोग की अनुमति"
    : consent?.description ||
      "Permission for use of health information";

const getFacility = (consent, isHindi) =>
  isHindi
    ? consent?.hindiFacility ||
      consent?.facility ||
      consent?.hospital ||
      "स्वास्थ्य केंद्र"
    : consent?.facility ||
      consent?.hospital ||
      "Healthcare facility";

const DetailRow = ({
  icon: Icon,
  label,
  value,
}) => (
  <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
    <Icon className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />

    <div className="min-w-0">
      <p className="text-[10px] uppercase tracking-wide font-bold text-slate-400">
        {label}
      </p>

      <p className="text-xs font-bold text-slate-800 mt-0.5 break-words">
        {value || "—"}
      </p>
    </div>
  </div>
);

const StatusCard = ({ active, isHindi }) => (
  <div
    className={`p-4 rounded-2xl border ${
      active
        ? "bg-emerald-50 border-emerald-200"
        : "bg-slate-100 border-slate-200"
    }`}
  >
    <div className="flex items-center gap-2">
      {active ? (
        <CheckCircle2 className="w-5 h-5 text-emerald-700" />
      ) : (
        <XCircle className="w-5 h-5 text-slate-500" />
      )}

      <div>
        <p
          className={`text-xs font-black ${
            active
              ? "text-emerald-900"
              : "text-slate-700"
          }`}
        >
          {active
            ? isHindi
              ? "सहमति सक्रिय है"
              : "Consent is active"
            : isHindi
            ? "सहमति सक्रिय नहीं है"
            : "Consent is not active"}
        </p>

        <p
          className={`text-[10px] mt-0.5 ${
            active
              ? "text-emerald-800/70"
              : "text-slate-500"
          }`}
        >
          {active
            ? isHindi
              ? "इस अनुमति के अनुसार संबंधित डेटा उपयोग किया जा सकता है।"
              : "The associated data use is currently permitted."
            : isHindi
            ? "इस अनुमति के आधार पर नया डेटा उपयोग नहीं होना चाहिए।"
            : "New use of data should not rely on this inactive consent."}
        </p>
      </div>
    </div>
  </div>
);

export const ConsentDetailsScreen = () => {
  const {
    privacyData,
    selectedConsent,
    withdrawConsent,
    regrantConsent,
    toggleConsent,
    setSelectedConsent,
    setScreen,
    prevScreen,
  } = useMobileStore();

  const { isHindi } = useLanguage();

  const activeConsents = Array.isArray(
    privacyData?.activeConsents
  )
    ? privacyData.activeConsents
    : [];

  const consentHistory = Array.isArray(
    privacyData?.consentHistory
  )
    ? privacyData.consentHistory
    : [];

  /*
   * PrivacyScreen also uses this screen as the entry
   * point for consent history. Therefore, if there is
   * no selected consent, show a history list instead
   * of rendering an empty details page.
   */
  if (!selectedConsent) {
    return (
      <div className="min-h-full flex flex-col bg-slate-50 text-slate-900 select-none">
        <MobileHeader
          title={
            isHindi
              ? "सहमति इतिहास"
              : "Consent History"
          }
          showBack={true}
          onBack={prevScreen}
        />

        <main className="flex-1 px-4 sm:px-6 py-4 sm:py-6 max-w-md md:max-w-2xl lg:max-w-3xl mx-auto w-full">
          <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
            <div className="flex items-center gap-2">
              <Clock3 className="w-4 h-4 text-teal-800" />

              <h1 className="text-sm font-black">
                {isHindi
                  ? "सहमति गतिविधियां"
                  : "Consent Activity"}
              </h1>
            </div>

            <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
              {isHindi
                ? "आपकी सहमति से संबंधित उपलब्ध गतिविधियां।"
                : "Available activity related to your consent decisions."}
            </p>

            {consentHistory.length === 0 ? (
              <div className="py-10 text-center">
                <ShieldCheck className="w-8 h-8 text-slate-300 mx-auto" />

                <p className="text-xs font-bold text-slate-600 mt-3">
                  {isHindi
                    ? "कोई इतिहास उपलब्ध नहीं है"
                    : "No consent history available"}
                </p>
              </div>
            ) : (
              <div className="mt-4 space-y-2.5">
                {consentHistory.map(
                  (entry, index) => (
                    <button
                      type="button"
                      key={
                        entry?.id ||
                        entry?.consentId ||
                        `history-${index}`
                      }
                      onClick={() => {
                        const matchingConsent =
                          activeConsents.find(
                            (consent) =>
                              getConsentId(
                                consent
                              ) ===
                              getConsentId(
                                entry
                              )
                          );

                        setSelectedConsent(
                          matchingConsent || {
                            ...entry,
                            status:
                              entry?.status ||
                              "INACTIVE",
                          }
                        );
                      }}
                      className="w-full p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-left hover:border-teal-300 transition cursor-pointer"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0">
                          <ShieldCheck className="w-4 h-4 text-slate-600" />
                        </div>

                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-black text-slate-800">
                            {isHindi
                              ? entry?.hindiTitle ||
                                entry?.title ||
                                "डेटा सहमति"
                              : entry?.title ||
                                "Data Consent"}
                          </p>

                          <p className="text-[10px] text-slate-500 mt-0.5">
                            {entry?.action ||
                              entry?.status ||
                              (isHindi
                                ? "सहमति गतिविधि"
                                : "Consent activity")}
                          </p>

                          <p className="text-[9px] text-slate-400 mt-1">
                            {entry?.date ||
                              entry?.timestamp ||
                              ""}
                          </p>
                        </div>
                      </div>
                    </button>
                  )
                )}
              </div>
            )}
          </section>
        </main>

        <BottomNavBar />
      </div>
    );
  }

  const consentId = getConsentId(selectedConsent);

  const currentlyActive =
    activeConsents.some(
      (consent) =>
        getConsentId(consent) === consentId
    ) || isConsentActive(selectedConsent);

  const title = getConsentTitle(
    selectedConsent,
    isHindi
  );

  const description = getConsentDescription(
    selectedConsent,
    isHindi
  );

  const facility = getFacility(
    selectedConsent,
    isHindi
  );

  const grantedAt =
    selectedConsent?.grantedAt ||
    selectedConsent?.createdAt ||
    selectedConsent?.date ||
    "";

  const expiresAt =
    selectedConsent?.expiresAt ||
    selectedConsent?.expiryDate ||
    "";

  const scope =
    selectedConsent?.scope ||
    selectedConsent?.purpose ||
    selectedConsent?.dataScope ||
    (isHindi
      ? "स्वास्थ्य जानकारी"
      : "Health information");

  const handleWithdraw = () => {
    if (typeof withdrawConsent === "function") {
      withdrawConsent(consentId);
    } else if (
      typeof toggleConsent === "function"
    ) {
      toggleConsent(consentId);
    }

    setSelectedConsent({
      ...selectedConsent,
      status: "INACTIVE",
      active: false,
    });
  };

  const handleRegrant = () => {
    if (typeof regrantConsent === "function") {
      regrantConsent(consentId);
    } else if (
      typeof toggleConsent === "function"
    ) {
      toggleConsent(consentId);
    }

    setSelectedConsent({
      ...selectedConsent,
      status: "ACTIVE",
      active: true,
    });
  };

  return (
    <div className="min-h-full flex flex-col bg-slate-50 text-slate-900 select-none">
      <MobileHeader
        title={
          isHindi
            ? "सहमति विवरण"
            : "Consent Details"
        }
        showBack={true}
        onBack={() => {
          setSelectedConsent(null);
          prevScreen();
        }}
      />

      <main className="flex-1 px-4 sm:px-6 py-4 sm:py-6 max-w-md md:max-w-2xl lg:max-w-3xl mx-auto w-full space-y-5">
        {/* Title */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-50 border border-teal-200 text-teal-800 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <div className="min-w-0">
              <h1 className="text-lg font-black leading-snug">
                {title}
              </h1>

              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                {description}
              </p>
            </div>
          </div>

          <div className="mt-4">
            <StatusCard
              active={currentlyActive}
              isHindi={isHindi}
            />
          </div>
        </section>

        {/* Scope */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
          <h2 className="text-sm font-black">
            {isHindi
              ? "सहमति का दायरा"
              : "Consent Scope"}
          </h2>

          <DetailRow
            icon={Building2}
            label={isHindi ? "सेवा / संस्था" : "Service / Facility"}
            value={facility}
          />

          <DetailRow
            icon={ShieldCheck}
            label={isHindi ? "डेटा दायरा" : "Data scope"}
            value={scope}
          />

          <DetailRow
            icon={CalendarDays}
            label={isHindi ? "प्रदान किया गया" : "Granted"}
            value={
              grantedAt ||
              (isHindi
                ? "उपलब्ध नहीं"
                : "Not available")
            }
          />

          <DetailRow
            icon={Clock3}
            label={isHindi ? "समाप्ति" : "Expires"}
            value={
              expiresAt ||
              (isHindi
                ? "निर्धारित नहीं"
                : "Not specified")
            }
          />
        </section>

        {/* Actions */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
          <h2 className="text-sm font-black">
            {isHindi
              ? "सहमति प्रबंधन"
              : "Manage Consent"}
          </h2>

          <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
            {isHindi
              ? "आप इस अनुमति को वापस ले सकते हैं। यदि सेवा को फिर से अनुमति देनी हो तो बाद में इसे सक्रिय किया जा सकता है।"
              : "You can withdraw this permission. If the service needs permission again, it can be re-granted later."}
          </p>

          <div className="mt-4 space-y-2.5">
            {currentlyActive ? (
              <button
                type="button"
                onClick={handleWithdraw}
                className="w-full min-h-[48px] rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 hover:bg-rose-100 flex items-center justify-center gap-2 text-xs font-black cursor-pointer transition active:scale-[0.99]"
              >
                <Ban className="w-4 h-4" />
                {isHindi
                  ? "सहमति वापस लें"
                  : "Withdraw consent"}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleRegrant}
                className="w-full min-h-[48px] rounded-2xl bg-teal-800 text-white hover:bg-teal-900 flex items-center justify-center gap-2 text-xs font-black cursor-pointer transition active:scale-[0.99]"
              >
                <RotateCcw className="w-4 h-4" />
                {isHindi
                  ? "सहमति फिर से दें"
                  : "Re-grant consent"}
              </button>
            )}
          </div>
        </section>

        {/* Safety */}
        <section className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />

            <div>
              <p className="text-xs font-black text-amber-900">
                {isHindi
                  ? "ध्यान दें"
                  : "Please note"}
              </p>

              <p className="text-[10px] text-amber-900/80 mt-1 leading-relaxed">
                {isHindi
                  ? "प्रोटोटाइप में सहमति परिवर्तन स्थानीय डेमो स्थिति पर लागू होता है। वास्तविक सिस्टम में सहमति प्रवर्तन संबंधित बैकएंड सेवा द्वारा किया जाएगा।"
                  : "In this prototype, consent changes affect the local demo state. Production enforcement would be handled by the connected backend service."}
              </p>
            </div>
          </div>
        </section>

        <button
          type="button"
          onClick={() => {
            setSelectedConsent(null);
            prevScreen();
          }}
          className="w-full min-h-[46px] rounded-2xl bg-white border border-slate-200 text-slate-800 flex items-center justify-center gap-2 text-xs font-bold hover:bg-slate-100 cursor-pointer transition"
        >
          <ArrowLeft className="w-4 h-4" />
          {isHindi
            ? "वापस जाएं"
            : "Back"}
        </button>

        <div className="pb-6" />
      </main>

      <BottomNavBar />
    </div>
  );
};

export default ConsentDetailsScreen;