import React, { useMemo } from "react";
import {
  ArrowLeft,
  CalendarDays,
  ChevronRight,
  Clock3,
  MapPin,
  Stethoscope,
} from "lucide-react";

import useMobileStore from "../../store/useMobileStore";

const SCREENS = {
  APPOINTMENTS: "APPOINTMENTS",
  VISIT_DETAILS: "VISIT_DETAILS",
};

export default function AppointmentsScreen() {
  const {
    appointments,
    setScreen,
    setSelectedVisit,
  } = useMobileStore();

  const appointmentData = useMemo(() => {
    if (!appointments) {
      return {
        today: null,
        upcoming: [],
        past: [],
      };
    }

    if (Array.isArray(appointments)) {
      return {
        today: null,
        upcoming: appointments,
        past: [],
      };
    }

    return {
      today: appointments.today || null,
      upcoming: Array.isArray(
        appointments.upcoming,
      )
        ? appointments.upcoming
        : [],
      past: Array.isArray(
        appointments.past,
      )
        ? appointments.past
        : [],
    };
  }, [appointments]);

  const openAppointment = (appointment) => {
    if (!appointment) {
      return;
    }

    setSelectedVisit?.({
      ...appointment,
      appointmentId:
        appointment.id ||
        appointment.appointmentId,
    });

    setScreen(
      SCREENS.VISIT_DETAILS,
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto min-h-screen w-full max-w-md">
        <header className="sticky top-0 z-10 flex items-center gap-3 border-b border-slate-200 bg-white px-5 py-4">
          <button
            type="button"
            onClick={() =>
              setScreen("MORE")
            }
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 active:scale-95"
            aria-label="Go back"
          >
            <ArrowLeft size={22} />
          </button>

          <div>
            <h1 className="text-lg font-bold">
              Appointments
            </h1>

            <p className="text-xs text-slate-500">
              Manage your consultations
            </p>
          </div>
        </header>

        <main className="px-5 py-6">
          {appointmentData.today && (
            <section className="mb-6">
              <SectionTitle>
                Today
              </SectionTitle>

              <AppointmentCard
                appointment={
                  appointmentData.today
                }
                highlighted
                onClick={() =>
                  openAppointment(
                    appointmentData.today,
                  )
                }
              />
            </section>
          )}

          <section className="mb-6">
            <SectionTitle>
              Upcoming
            </SectionTitle>

            {appointmentData.upcoming.length >
            0 ? (
              <div className="space-y-3">
                {appointmentData.upcoming.map(
                  (appointment, index) => (
                    <AppointmentCard
                      key={
                        appointment.id ||
                        appointment.appointmentId ||
                        `upcoming-${index}`
                      }
                      appointment={
                        appointment
                      }
                      onClick={() =>
                        openAppointment(
                          appointment,
                        )
                      }
                    />
                  ),
                )}
              </div>
            ) : (
              <EmptyState text="No upcoming appointments." />
            )}
          </section>

          <section>
            <SectionTitle>
              Previous Appointments
            </SectionTitle>

            {appointmentData.past.length >
            0 ? (
              <div className="space-y-3">
                {appointmentData.past.map(
                  (appointment, index) => (
                    <AppointmentCard
                      key={
                        appointment.id ||
                        appointment.appointmentId ||
                        `past-${index}`
                      }
                      appointment={
                        appointment
                      }
                      onClick={() =>
                        openAppointment(
                          appointment,
                        )
                      }
                    />
                  ),
                )}
              </div>
            ) : (
              <EmptyState text="No previous appointments." />
            )}
          </section>
        </main>
      </div>
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <h2 className="mb-3 text-sm font-bold text-slate-800">
      {children}
    </h2>
  );
}

function AppointmentCard({
  appointment,
  highlighted = false,
  onClick,
}) {
  const doctor =
    appointment.doctor ||
    appointment.doctorName ||
    "Doctor";

  const specialty =
    appointment.specialty ||
    appointment.department ||
    "General OPD";

  const date =
    appointment.date ||
    appointment.appointmentDate ||
    appointment.visitDate ||
    "Date not available";

  const time =
    appointment.time ||
    appointment.appointmentTime ||
    appointment.timeSlot ||
    "Time not available";

  const location =
    appointment.location ||
    appointment.facility ||
    "Civil Hospital OPD";

  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full rounded-3xl border bg-white p-5 text-left shadow-sm transition active:scale-[0.99] ${
        highlighted
          ? "border-blue-200 ring-2 ring-blue-50"
          : "border-slate-100"
      }`}
    >
      {highlighted && (
        <div className="mb-4 inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
          Today's appointment
        </div>
      )}

      <div className="flex items-start gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-blue-50">
          <Stethoscope
            size={21}
            className="text-blue-600"
          />
        </div>

        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-bold text-slate-900">
            {doctor}
          </h3>

          <p className="mt-1 text-xs text-slate-500">
            {specialty}
          </p>
        </div>

        <ChevronRight
          size={19}
          className="mt-1 shrink-0 text-slate-400"
        />
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <Detail icon={CalendarDays}>
          {date}
        </Detail>

        <Detail icon={Clock3}>
          {time}
        </Detail>
      </div>

      <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
        <MapPin size={14} />
        <span className="truncate">
          {location}
        </span>
      </div>
    </button>
  );
}

function Detail({
  icon: Icon,
  children,
}) {
  return (
    <div className="rounded-2xl bg-slate-50 px-3 py-2.5">
      <div className="mb-1 flex items-center gap-1.5 text-slate-400">
        <Icon size={13} />
      </div>

      <p className="truncate text-xs font-semibold text-slate-700">
        {children}
      </p>
    </div>
  );
}

function EmptyState({ text }) {
  return (
    <div className="rounded-3xl border border-dashed border-slate-200 bg-white px-5 py-8 text-center">
      <CalendarDays
        size={28}
        className="mx-auto mb-3 text-slate-300"
      />

      <p className="text-sm text-slate-500">
        {text}
      </p>
    </div>
  );
}