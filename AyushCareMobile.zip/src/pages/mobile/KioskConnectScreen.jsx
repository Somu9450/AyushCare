import React, { useEffect, useState } from "react";
import {
  ArrowLeft,
  Camera,
  CheckCircle2,
  Loader2,
  QrCode,
  ShieldCheck,
  Smartphone,
  Wifi,
  XCircle,
} from "lucide-react";

import {
  connectKioskSession,
  DEFAULT_DEMO_TOKEN,
  parseKioskQrReference,
} from "../../services/kioskSessionService";

const DEFAULT_DEMO_REFERENCE = DEFAULT_DEMO_TOKEN;

export default function KioskConnectScreen({
  onBack,
  onConnected,
}) {
  const [reference, setReference] = useState("");
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const isConnecting = status === "connecting";
  const isConnected = status === "connected";

  useEffect(() => {
    const params = new URLSearchParams(
      window.location.search,
    );

    const qrReference =
      params.get("session") ||
      params.get("sessionRef") ||
      params.get("token") ||
      params.get("ref");

    if (qrReference) {
      setReference(qrReference);
    }
  }, []);

  const handleConnect = async (
    suppliedReference = reference,
  ) => {
    setError("");
    setStatus("connecting");

    const parsedReference =
      parseKioskQrReference(suppliedReference);

    if (!parsedReference) {
      setStatus("error");
      setError(
        "Please scan a valid kiosk QR code or enter a session reference.",
      );
      return;
    }

    try {
      const result =
        await connectKioskSession(parsedReference);

      if (!result?.success || !result?.session) {
        setStatus("error");
        setError(
          result?.error ||
            "Unable to connect to the kiosk.",
        );
        return;
      }

      setStatus("connected");

      if (typeof onConnected === "function") {
        onConnected(result.session);
      }
    } catch (connectionError) {
      console.error(
        "Kiosk connection failed:",
        connectionError,
      );

      setStatus("error");
      setError(
        "Something went wrong while connecting. Please try again.",
      );
    }
  };

  const handleDemoConnection = () => {
    setReference(DEFAULT_DEMO_REFERENCE);
    handleConnect(DEFAULT_DEMO_REFERENCE);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto flex min-h-screen w-full max-w-md flex-col">
        {/* Header */}
        <header className="flex items-center gap-3 border-b border-slate-200 bg-white px-5 py-4">
          <button
            type="button"
            onClick={onBack}
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 transition active:scale-95"
            aria-label="Go back"
          >
            <ArrowLeft size={22} />
          </button>

          <div>
            <h1 className="text-lg font-bold">
              Connect to Kiosk
            </h1>

            <p className="text-xs text-slate-500">
              Link this phone to your current visit
            </p>
          </div>
        </header>

        {/* Main */}
        <main className="flex flex-1 flex-col px-5 py-6">
          {/* Connection illustration */}
          <section className="mb-6 rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-100">
            <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-3xl bg-blue-50">
              {isConnected ? (
                <CheckCircle2
                  size={42}
                  className="text-green-600"
                />
              ) : (
                <QrCode
                  size={42}
                  className="text-blue-600"
                />
              )}
            </div>

            <h2 className="text-xl font-bold">
              {isConnected
                ? "Kiosk Connected"
                : "Scan the kiosk QR"}
            </h2>

            <p className="mx-auto mt-2 max-w-xs text-sm leading-5 text-slate-500">
              {isConnected
                ? "Your mobile device is now linked to the active kiosk session."
                : "Scan the QR code displayed on the AyushCare kiosk to continue your visit on this phone."}
            </p>
          </section>

          {/* Status */}
          {status === "connecting" && (
            <div className="mb-5 flex items-center gap-3 rounded-2xl border border-blue-100 bg-blue-50 p-4">
              <Loader2
                size={20}
                className="animate-spin text-blue-600"
              />

              <div>
                <p className="text-sm font-semibold text-blue-900">
                  Connecting to kiosk…
                </p>

                <p className="text-xs text-blue-700">
                  Verifying the temporary session.
                </p>
              </div>
            </div>
          )}

          {status === "connected" && (
            <div className="mb-5 flex items-center gap-3 rounded-2xl border border-green-100 bg-green-50 p-4">
              <Wifi
                size={20}
                className="text-green-600"
              />

              <div>
                <p className="text-sm font-semibold text-green-900">
                  Connection successful
                </p>

                <p className="text-xs text-green-700">
                  You can now continue your patient journey.
                </p>
              </div>
            </div>
          )}

          {status === "error" && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-red-100 bg-red-50 p-4">
              <XCircle
                size={20}
                className="mt-0.5 shrink-0 text-red-600"
              />

              <div>
                <p className="text-sm font-semibold text-red-900">
                  Connection failed
                </p>

                <p className="mt-1 text-xs leading-5 text-red-700">
                  {error}
                </p>
              </div>
            </div>
          )}

          {/* Reference input */}
          {!isConnected && (
            <>
              <section className="mb-5">
                <label
                  htmlFor="kiosk-session-reference"
                  className="mb-2 block text-sm font-semibold text-slate-800"
                >
                  Kiosk session reference
                </label>

                <input
                  id="kiosk-session-reference"
                  value={reference}
                  onChange={(event) => {
                    setReference(event.target.value);
                    setError("");

                    if (status !== "idle") {
                      setStatus("idle");
                    }
                  }}
                  placeholder="Scan QR or enter reference"
                  autoComplete="off"
                  className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3.5 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-50"
                />
              </section>

              <button
                type="button"
                onClick={() => handleConnect()}
                disabled={
                  isConnecting ||
                  !reference.trim()
                }
                className="mb-3 flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-blue-600 px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-blue-700 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isConnecting ? (
                  <>
                    <Loader2
                      size={18}
                      className="animate-spin"
                    />
                    Connecting…
                  </>
                ) : (
                  <>
                    <Wifi size={18} />
                    Connect to Kiosk
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleDemoConnection}
                disabled={isConnecting}
                className="mb-6 flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 active:scale-[0.99] disabled:opacity-50"
              >
                <QrCode size={17} />
                Use Demo Kiosk
              </button>

              {/* QR explanation */}
              <section className="rounded-3xl border border-slate-200 bg-white p-5">
                <div className="mb-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100">
                    <Camera
                      size={20}
                      className="text-slate-700"
                    />
                  </div>

                  <div>
                    <p className="text-sm font-semibold">
                      How it works
                    </p>

                    <p className="text-xs text-slate-500">
                      Three simple steps
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <Step
                    number="1"
                    icon={QrCode}
                    title="Open the kiosk QR"
                    description="The kiosk displays a temporary connection QR."
                  />

                  <Step
                    number="2"
                    icon={Smartphone}
                    title="Scan with your phone"
                    description="The QR carries a short-lived session reference."
                  />

                  <Step
                    number="3"
                    icon={ShieldCheck}
                    title="Continue securely"
                    description="Your medical information is not stored inside the QR."
                  />
                </div>
              </section>
            </>
          )}

          {/* Connected state */}
          {isConnected && (
            <section className="rounded-3xl border border-green-100 bg-white p-5 shadow-sm">
              <div className="mb-5 flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-green-50">
                  <CheckCircle2
                    size={22}
                    className="text-green-600"
                  />
                </div>

                <div>
                  <p className="font-semibold">
                    Ready to continue
                  </p>

                  <p className="text-xs text-slate-500">
                    Your phone is linked with this kiosk.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  typeof onConnected === "function" &&
                  onConnected()
                }
                className="flex min-h-12 w-full items-center justify-center rounded-2xl bg-blue-600 px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-blue-700 active:scale-[0.99]"
              >
                Continue
              </button>
            </section>
          )}

          <div className="mt-auto pt-6">
            <p className="text-center text-xs leading-5 text-slate-400">
              For this prototype, the demo kiosk connection is
              simulated. Production sessions should be issued
              and validated by the backend.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}

function Step({
  number,
  icon: Icon,
  title,
  description,
}) {
  return (
    <div className="flex gap-3">
      <div className="relative flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-blue-50 text-xs font-bold text-blue-600">
        {number}
      </div>

      <div className="min-w-0">
        <div className="mb-1 flex items-center gap-2">
          <Icon size={15} className="text-slate-500" />

          <p className="text-sm font-semibold">
            {title}
          </p>
        </div>

        <p className="text-xs leading-5 text-slate-500">
          {description}
        </p>
      </div>
    </div>
  );
}