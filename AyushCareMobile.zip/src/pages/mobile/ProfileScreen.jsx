import React, { useState } from "react";
import {
  UserRound,
  Phone,
  CreditCard,
  HeartPulse,
  CalendarDays,
  MapPin,
  Pencil,
  Check,
  X,
  ShieldCheck,
  ArrowLeft,
} from "lucide-react";

import useMobileStore from "../../store/useMobileStore";
import MobileHeader from "../../components/mobile/MobileHeader";
import BottomNavBar from "../../components/mobile/BottomNavBar";
import useLanguage from "../../i18n/translations";

const InfoRow = ({
  icon: Icon,
  label,
  value,
  editable = false,
  onEdit,
}) => (
  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3">
    <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0">
      <Icon className="w-4 h-4 text-slate-600" />
    </div>

    <div className="min-w-0 flex-1">
      <p className="text-[10px] uppercase tracking-wide font-bold text-slate-400">
        {label}
      </p>

      <p className="text-sm font-bold text-slate-800 mt-0.5 break-words">
        {value || "—"}
      </p>
    </div>

    {editable && (
      <button
        type="button"
        onClick={onEdit}
        className="w-8 h-8 rounded-lg bg-white border border-slate-200 text-teal-800 flex items-center justify-center shrink-0 hover:bg-teal-50 cursor-pointer"
        aria-label="Edit"
      >
        <Pencil className="w-3.5 h-3.5" />
      </button>
    )}
  </div>
);

export const ProfileScreen = () => {
  const {
    patient,
    updatePatientProfile,
    prevScreen,
  } = useMobileStore();

  const { isHindi } = useLanguage();

  const [editingField, setEditingField] =
    useState(null);

  const [draftValue, setDraftValue] =
    useState("");

  const [savedMessage, setSavedMessage] =
    useState(false);

  const displayName =
    patient?.name ||
    patient?.fullName ||
    (isHindi ? "मरीज़" : "Patient");

  const hindiName =
    patient?.hindiName || "";

  const mobile =
    patient?.mobile ||
    patient?.phone ||
    patient?.maskedMobile ||
    "";

  const abha =
    patient?.abhaNumber ||
    patient?.abha ||
    "";

  const aadhaar =
    patient?.aadhaarNumber ||
    patient?.aadhaar ||
    patient?.maskedAadhaar ||
    "";

  const dateOfBirth =
    patient?.dateOfBirth ||
    patient?.dob ||
    "";

  const age =
    patient?.age !== undefined &&
    patient?.age !== null
      ? `${patient.age} ${
          isHindi ? "वर्ष" : "years"
        }`
      : "";

  const gender =
    patient?.gender ||
    patient?.sex ||
    "";

  const address =
    patient?.address ||
    patient?.city ||
    "";

  const startEdit = (field, value) => {
    setEditingField(field);
    setDraftValue(value || "");
    setSavedMessage(false);
  };

  const cancelEdit = () => {
    setEditingField(null);
    setDraftValue("");
  };

  const saveEdit = () => {
    if (!editingField) return;

    if (typeof updatePatientProfile === "function") {
      updatePatientProfile({
        [editingField]: draftValue,
      });
    }

    setEditingField(null);
    setDraftValue("");
    setSavedMessage(true);

    window.setTimeout(() => {
      setSavedMessage(false);
    }, 2200);
  };

  return (
    <div className="min-h-full flex flex-col bg-slate-50 text-slate-900 select-none">
      <MobileHeader
        title={isHindi ? "प्रोफ़ाइल" : "Profile"}
        showBack={true}
        onBack={prevScreen}
      />

      <main className="flex-1 px-4 sm:px-6 py-4 sm:py-6 max-w-md md:max-w-2xl lg:max-w-3xl mx-auto w-full space-y-5">
        {/* Saved message */}
        {savedMessage && (
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center gap-2 text-emerald-800">
            <Check className="w-4 h-4" />

            <span className="text-xs font-bold">
              {isHindi
                ? "प्रोफ़ाइल अपडेट हो गई ✓"
                : "Profile updated ✓"}
            </span>
          </div>
        )}

        {/* Identity */}
        <section className="p-5 rounded-3xl bg-gradient-to-br from-teal-800 to-teal-950 text-white shadow-md">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-3xl bg-white/10 border border-white/20 flex items-center justify-center text-2xl font-black shrink-0">
              {displayName.charAt(0)}
            </div>

            <div className="min-w-0">
              <h1 className="text-xl font-black truncate">
                {displayName}
              </h1>

              {hindiName && (
                <p className="text-xs text-teal-100 mt-0.5">
                  {hindiName}
                </p>
              )}

              {mobile && (
                <p className="text-xs text-teal-100/80 mt-2">
                  {mobile}
                </p>
              )}
            </div>
          </div>
        </section>

        {/* Basic information */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <UserRound className="w-4 h-4 text-teal-800" />

            <h2 className="text-sm font-black">
              {isHindi
                ? "व्यक्तिगत जानकारी"
                : "Personal Information"}
            </h2>
          </div>

          <InfoRow
            icon={UserRound}
            label={isHindi ? "नाम" : "Name"}
            value={displayName}
            editable={true}
            onEdit={() =>
              startEdit("name", displayName)
            }
          />

          <InfoRow
            icon={Phone}
            label={isHindi ? "मोबाइल" : "Mobile"}
            value={mobile}
          />

          <InfoRow
            icon={CalendarDays}
            label={isHindi ? "जन्म तिथि" : "Date of birth"}
            value={dateOfBirth}
          />

          <InfoRow
            icon={CalendarDays}
            label={isHindi ? "उम्र" : "Age"}
            value={age}
          />

          <InfoRow
            icon={UserRound}
            label={isHindi ? "लिंग" : "Gender"}
            value={gender}
          />

          <InfoRow
            icon={MapPin}
            label={isHindi ? "पता" : "Address"}
            value={address}
            editable={true}
            onEdit={() =>
              startEdit("address", address)
            }
          />
        </section>

        {/* Identity identifiers */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <CreditCard className="w-4 h-4 text-teal-800" />

            <h2 className="text-sm font-black">
              {isHindi
                ? "पहचान विवरण"
                : "Identity Details"}
            </h2>
          </div>

          <InfoRow
            icon={HeartPulse}
            label="ABHA"
            value={abha}
          />

          <InfoRow
            icon={CreditCard}
            label={
              isHindi
                ? "आधार"
                : "Aadhaar"
            }
            value={aadhaar}
          />

          <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
            <div className="flex items-start gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-700 shrink-0 mt-0.5" />

              <p className="text-[10px] text-blue-900/80 leading-relaxed">
                {isHindi
                  ? "पहचान नंबर केवल डेमो प्रोफ़ाइल जानकारी के रूप में दिखाए जाते हैं। वास्तविक सिस्टम में इन्हें सुरक्षित तरीके से सत्यापित और संरक्षित किया जाएगा।"
                  : "Identity numbers are shown only as prototype profile information. A production system would verify and protect them using appropriate secure mechanisms."}
              </p>
            </div>
          </div>
        </section>

        {/* Health profile */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <HeartPulse className="w-4 h-4 text-teal-800" />

            <h2 className="text-sm font-black">
              {isHindi
                ? "स्वास्थ्य प्रोफ़ाइल"
                : "Health Profile"}
            </h2>
          </div>

          <InfoRow
            icon={HeartPulse}
            label={
              isHindi
                ? "रक्त समूह"
                : "Blood group"
            }
            value={
              patient?.bloodGroup ||
              patient?.bloodType ||
              ""
            }
          />

          <InfoRow
            icon={AlertCircle}
            label={
              isHindi
                ? "एलर्जी"
                : "Allergies"
            }
            value={
              Array.isArray(patient?.allergies)
                ? patient.allergies.join(", ")
                : patient?.allergies || ""
            }
          />

          <p className="text-[10px] text-slate-400 leading-relaxed">
            {isHindi
              ? "स्वास्थ्य प्रोफ़ाइल में दिखाई गई जानकारी उपलब्ध रोगी रिकॉर्ड पर आधारित है।"
              : "Information shown in the health profile is based on available patient records."}
          </p>
        </section>

        {/* Edit modal */}
        {editingField && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
            <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl">
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-base font-black">
                  {isHindi
                    ? "प्रोफ़ाइल संपादित करें"
                    : "Edit Profile"}
                </h2>

                <button
                  type="button"
                  onClick={cancelEdit}
                  className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <label className="block mt-5">
                <span className="text-xs font-black text-slate-700">
                  {editingField === "name"
                    ? isHindi
                      ? "नाम"
                      : "Name"
                    : isHindi
                    ? "पता"
                    : "Address"}
                </span>

                <input
                  type="text"
                  value={draftValue}
                  onChange={(event) =>
                    setDraftValue(
                      event.target.value
                    )
                  }
                  className="w-full mt-2 h-12 px-3 rounded-xl border border-slate-300 outline-none text-sm focus:border-teal-600 focus:ring-2 focus:ring-teal-100"
                  autoFocus
                />
              </label>

              <div className="flex gap-2 mt-5">
                <button
                  type="button"
                  onClick={cancelEdit}
                  className="flex-1 h-11 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  {isHindi ? "रद्द करें" : "Cancel"}
                </button>

                <button
                  type="button"
                  onClick={saveEdit}
                  className="flex-1 h-11 rounded-xl bg-teal-800 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  {isHindi ? "सहेजें" : "Save"}
                </button>
              </div>
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={prevScreen}
          className="w-full min-h-[46px] rounded-2xl bg-white border border-slate-200 text-slate-800 flex items-center justify-center gap-2 text-xs font-bold hover:bg-slate-100 cursor-pointer transition"
        >
          <ArrowLeft className="w-4 h-4" />
          {isHindi ? "वापस जाएं" : "Back"}
        </button>

        <div className="pb-6" />
      </main>

      <BottomNavBar />
    </div>
  );
};

export default ProfileScreen;