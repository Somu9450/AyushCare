import React, { useState } from "react";
import {
  Settings,
  Globe2,
  Volume2,
  Type,
  Accessibility,
  Check,
  ChevronRight,
  RotateCcw,
  Info,
} from "lucide-react";

import useMobileStore, { SCREENS } from "../../store/useMobileStore";
import MobileHeader from "../../components/mobile/MobileHeader";
import BottomNavBar from "../../components/mobile/BottomNavBar";
import useLanguage from "../../i18n/translations";

const Toggle = ({ enabled, onChange, label }) => (
  <button
    type="button"
    role="switch"
    aria-checked={enabled}
    aria-label={label}
    onClick={() => onChange(!enabled)}
    className={`relative w-12 h-7 rounded-full shrink-0 transition cursor-pointer ${
      enabled ? "bg-teal-800" : "bg-slate-300"
    }`}
  >
    <span
      className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
        enabled ? "translate-x-6" : "translate-x-1"
      }`}
    />
  </button>
);

const LanguageButton = ({
  active,
  title,
  subtitle,
  onClick,
}) => (
  <button
    type="button"
    onClick={onClick}
    className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between gap-3 transition cursor-pointer ${
      active
        ? "bg-teal-50 border-teal-600 ring-1 ring-teal-600/10"
        : "bg-white border-slate-200 hover:border-slate-300"
    }`}
  >
    <div className="min-w-0">
      <p className="text-sm font-black text-slate-900">
        {title}
      </p>
      <p className="text-[10px] text-slate-500 mt-0.5">
        {subtitle}
      </p>
    </div>

    {active ? (
      <span className="w-7 h-7 rounded-full bg-teal-800 text-white flex items-center justify-center shrink-0">
        <Check className="w-4 h-4" />
      </span>
    ) : (
      <span className="w-7 h-7 rounded-full border border-slate-200 shrink-0" />
    )}
  </button>
);

export const SettingsScreen = () => {
  const {
    selectedLanguage,
    setSelectedLanguage,
    accessibilitySettings,
    updateAccessibilitySettings,
    setScreen,
    prevScreen,
  } = useMobileStore();

  const { t, isHindi } = useLanguage();

  const [toastMessage, setToastMessage] =
    useState(null);

  const showToast = (message) => {
    setToastMessage(message);

    window.clearTimeout(
      window.__ayushcareSettingsToastTimer
    );

    window.__ayushcareSettingsToastTimer =
      window.setTimeout(() => {
        setToastMessage(null);
      }, 2200);
  };

  const currentLanguage =
    selectedLanguage === "hi" ||
    selectedLanguage === "hindi"
      ? "hi"
      : "en";

  const largeText =
    accessibilitySettings?.largeText ??
    accessibilitySettings?.largeFont ??
    false;

  const highContrast =
    accessibilitySettings?.highContrast ?? false;

  const reducedMotion =
    accessibilitySettings?.reducedMotion ?? false;

  const audioEnabled =
    accessibilitySettings?.audioEnabled ??
    accessibilitySettings?.hindiAudioEnabled ??
    true;

  const handleLanguageChange = (language) => {
    setSelectedLanguage(language);

    showToast(
      language === "hi"
        ? "भाषा हिंदी में बदल दी गई ✓"
        : "Language changed to English ✓"
    );
  };

  const updateAccessibility = (
    key,
    value,
    successMessage
  ) => {
    updateAccessibilitySettings({
      [key]: value,
    });

    showToast(
      successMessage ||
        (isHindi
          ? "सेटिंग अपडेट की गई ✓"
          : "Setting updated ✓")
    );
  };

  const resetAccessibility = () => {
    updateAccessibilitySettings({
      largeText: false,
      largeFont: false,
      highContrast: false,
      reducedMotion: false,
      audioEnabled: true,
      hindiAudioEnabled: true,
    });

    showToast(
      isHindi
        ? "पहुंच सेटिंग रीसेट की गई"
        : "Accessibility settings reset"
    );
  };

  return (
    <div className="min-h-full flex flex-col bg-slate-50 text-slate-900 select-none">
      <MobileHeader
        title={t("settings_title")}
        showBack={true}
        onBack={prevScreen}
      />

      <main className="flex-1 px-4 sm:px-6 py-4 sm:py-6 max-w-md md:max-w-2xl lg:max-w-3xl mx-auto w-full space-y-5">
        {/* Toast */}
        {toastMessage && (
          <div className="p-3 rounded-2xl bg-slate-950 text-white flex items-center gap-2 shadow-lg">
            <Check className="w-4 h-4 text-teal-300 shrink-0" />
            <span className="text-xs font-bold">
              {toastMessage}
            </span>
          </div>
        )}

        {/* Header card */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-teal-50 border border-teal-200 text-teal-800 flex items-center justify-center">
              <Settings className="w-5 h-5" />
            </div>

            <div>
              <h1 className="text-lg font-black">
                {t("settings_title")}
              </h1>

              <p className="text-xs text-slate-500 mt-0.5">
                {isHindi
                  ? "ऐप को अपनी जरूरत के अनुसार सेट करें।"
                  : "Adjust the app to your preferences."}
              </p>
            </div>
          </div>
        </section>

        {/* Language */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-teal-800" />
            <h2 className="text-sm font-black">
              {isHindi ? "भाषा" : "Language"}
            </h2>
          </div>

          <p className="text-[11px] text-slate-500 leading-relaxed">
            {isHindi
              ? "ऐप के इंटरफ़ेस की भाषा चुनें।"
              : "Choose the language used across the app."}
          </p>

          <div className="space-y-2">
            <LanguageButton
              active={currentLanguage === "en"}
              title="English"
              subtitle="Use English throughout the app"
              onClick={() =>
                handleLanguageChange("en")
              }
            />

            <LanguageButton
              active={currentLanguage === "hi"}
              title="हिंदी"
              subtitle="ऐप में हिंदी का उपयोग करें"
              onClick={() =>
                handleLanguageChange("hi")
              }
            />
          </div>
        </section>

        {/* Accessibility */}
        <section className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Accessibility className="w-4 h-4 text-teal-800" />
              <h2 className="text-sm font-black">
                {isHindi
                  ? "पहुंच सुविधाएं"
                  : "Accessibility"}
              </h2>
            </div>

            <button
              type="button"
              onClick={resetAccessibility}
              className="inline-flex items-center gap-1 text-[10px] font-bold text-teal-800 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              {isHindi ? "रीसेट" : "Reset"}
            </button>
          </div>

          {/* Large text */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4">
            <div className="flex items-start gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0">
                <Type className="w-4 h-4 text-slate-600" />
              </div>

              <div>
                <p className="text-xs font-black">
                  {isHindi
                    ? "बड़ा टेक्स्ट"
                    : "Larger text"}
                </p>

                <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                  {isHindi
                    ? "पाठ को पढ़ने में आसान बनाएं।"
                    : "Make text easier to read."}
                </p>
              </div>
            </div>

            <Toggle
              enabled={largeText}
              onChange={(value) =>
                updateAccessibility(
                  "largeText",
                  value
                )
              }
              label={
                isHindi
                  ? "बड़ा टेक्स्ट"
                  : "Larger text"
              }
            />
          </div>

          {/* High contrast */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4">
            <div className="min-w-0">
              <p className="text-xs font-black">
                {isHindi
                  ? "उच्च कंट्रास्ट"
                  : "High contrast"}
              </p>

              <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                {isHindi
                  ? "पाठ और इंटरफ़ेस के बीच स्पष्ट अंतर रखें।"
                  : "Increase visual contrast between text and interface."}
              </p>
            </div>

            <Toggle
              enabled={highContrast}
              onChange={(value) =>
                updateAccessibility(
                  "highContrast",
                  value
                )
              }
              label={
                isHindi
                  ? "उच्च कंट्रास्ट"
                  : "High contrast"
              }
            />
          </div>

          {/* Reduced motion */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4">
            <div className="min-w-0">
              <p className="text-xs font-black">
                {isHindi
                  ? "कम एनिमेशन"
                  : "Reduced motion"}
              </p>

              <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                {isHindi
                  ? "अनावश्यक दृश्य एनिमेशन कम करें।"
                  : "Reduce non-essential interface animations."}
              </p>
            </div>

            <Toggle
              enabled={reducedMotion}
              onChange={(value) =>
                updateAccessibility(
                  "reducedMotion",
                  value
                )
              }
              label={
                isHindi
                  ? "कम एनिमेशन"
                  : "Reduced motion"
              }
            />
          </div>

          {/* Audio */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4">
            <div className="flex items-start gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0">
                <Volume2 className="w-4 h-4 text-slate-600" />
              </div>

              <div>
                <p className="text-xs font-black">
                  {isHindi
                    ? "हिंदी ऑडियो"
                    : "Hindi audio"}
                </p>

                <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                  {isHindi
                    ? "उपलब्ध स्क्रीन पर हिंदी टेक्स्ट सुनें।"
                    : "Enable Hindi text-to-speech where available."}
                </p>
              </div>
            </div>

            <Toggle
              enabled={audioEnabled}
              onChange={(value) =>
                updateAccessibility(
                  "audioEnabled",
                  value
                )
              }
              label={
                isHindi
                  ? "हिंदी ऑडियो"
                  : "Hindi audio"
              }
            />
          </div>
        </section>

        {/* Privacy shortcut */}
        <button
          type="button"
          onClick={() => setScreen(SCREENS.PRIVACY)}
          className="w-full p-4 rounded-2xl bg-white border border-slate-200 flex items-center gap-3 text-left hover:border-teal-300 transition cursor-pointer"
        >
          <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-800 flex items-center justify-center shrink-0">
            <Info className="w-4 h-4" />
          </div>

          <div className="flex-1 min-w-0">
            <p className="text-xs font-black text-slate-900">
              {isHindi
                ? "गोपनीयता और डेटा नियंत्रण"
                : "Privacy & Data Control"}
            </p>

            <p className="text-[10px] text-slate-500 mt-0.5">
              {isHindi
                ? "स्वास्थ्य जानकारी साझाकरण और सहमति प्रबंधित करें।"
                : "Manage health-information sharing and consent."}
            </p>
          </div>

          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
        </button>

        <div className="pb-6" />
      </main>

      <BottomNavBar />
    </div>
  );
};

export default SettingsScreen;