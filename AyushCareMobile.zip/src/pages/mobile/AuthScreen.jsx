import React, { useEffect, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Fingerprint,
  HeartPulse,
  LockKeyhole,
  Smartphone,
  ShieldCheck,
  UserRound,
  KeyRound,
  ArrowLeft,
  RefreshCw,
} from "lucide-react";

import useMobileStore, { SCREENS } from "../../store/useMobileStore";
import useLanguage from "../../i18n/translations";

const AUTH_METHODS = {
  MOBILE: "mobile",
  ABHA: "abha",
  AADHAAR: "aadhaar",
};

const DEMO_OTP = "123456";

const normalizeMethod = (method) => {
  if (method === AUTH_METHODS.ABHA) return AUTH_METHODS.ABHA;
  if (method === AUTH_METHODS.AADHAAR) return AUTH_METHODS.AADHAAR;
  return AUTH_METHODS.MOBILE;
};

export const AuthScreen = () => {
  const {
    isAuthenticated,
    authType,
    patient,
    loginPatient,
    setScreen,
    kioskSession,
    connectKioskSession,
  } = useMobileStore();

  const { isHindi } = useLanguage();

  const [method, setMethod] = useState(
    normalizeMethod(authType)
  );

  const [identifier, setIdentifier] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState("IDENTIFIER");
  const [error, setError] = useState("");
  const [resendTimer, setResendTimer] = useState(0);

  useEffect(() => {
    if (isAuthenticated) {
      setScreen(SCREENS.M1);
    }
  }, [isAuthenticated, setScreen]);

  useEffect(() => {
    if (resendTimer <= 0) return;

    const timer = window.setInterval(() => {
      setResendTimer((value) => Math.max(0, value - 1));
    }, 1000);

    return () => window.clearInterval(timer);
  }, [resendTimer]);

  const getIdentifierLabel = () => {
    switch (method) {
      case AUTH_METHODS.ABHA:
        return isHindi ? "ABHA नंबर" : "ABHA Number";
      case AUTH_METHODS.AADHAAR:
        return isHindi ? "आधार नंबर" : "Aadhaar Number";
      default:
        return isHindi ? "मोबाइल नंबर" : "Mobile Number";
    }
  };

  const getIdentifierPlaceholder = () => {
    switch (method) {
      case AUTH_METHODS.ABHA:
        return isHindi ? "14 अंकों का ABHA नंबर" : "14-digit ABHA number";
      case AUTH_METHODS.AADHAAR:
        return isHindi ? "12 अंकों का आधार नंबर" : "12-digit Aadhaar number";
      default:
        return isHindi ? "10 अंकों का मोबाइल नंबर" : "10-digit mobile number";
    }
  };

  const validateIdentifier = () => {
    const value = identifier.replace(/\s+/g, "");

    if (!value) {
      return isHindi
        ? "कृपया अपना विवरण दर्ज करें।"
        : "Please enter your details.";
    }

    if (method === AUTH_METHODS.MOBILE) {
      if (!/^\d{10}$/.test(value)) {
        return isHindi
          ? "कृपया 10 अंकों का मोबाइल नंबर दर्ज करें।"
          : "Enter a valid 10-digit mobile number.";
      }
    }

    if (method === AUTH_METHODS.AADHAAR) {
      if (!/^\d{12}$/.test(value)) {
        return isHindi
          ? "कृपया 12 अंकों का आधार नंबर दर्ज करें।"
          : "Enter a valid 12-digit Aadhaar number.";
      }
    }

    if (method === AUTH_METHODS.ABHA) {
      const compact = value.replace(/-/g, "");

      if (!/^\d{14}$/.test(compact)) {
        return isHindi
          ? "कृपया 14 अंकों का ABHA नंबर दर्ज करें।"
          : "Enter a valid 14-digit ABHA number.";
      }
    }

    return "";
  };

  const handleSendOtp = () => {
    const validationError = validateIdentifier();

    if (validationError) {
      setError(validationError);
      return;
    }

    setError("");
    setOtp("");
    setStep("OTP");
    setResendTimer(30);
  };

  const handleVerifyOtp = () => {
    if (!/^\d{6}$/.test(otp)) {
      setError(
        isHindi
          ? "कृपया 6 अंकों का OTP दर्ज करें।"
          : "Enter the 6-digit OTP."
      );
      return;
    }

    if (otp !== DEMO_OTP) {
      setError(
        isHindi
          ? "डेमो OTP सही नहीं है। 123456 इस्तेमाल करें।"
          : "Invalid demo OTP. Use 123456."
      );
      return;
    }

    setError("");

    if (typeof loginPatient === "function") {
      loginPatient({
        authType: method,
        identifier,
      });
    } else {
      setScreen(SCREENS.M1);
    }
  };

  const handleResend = () => {
    if (resendTimer > 0) return;

    setOtp("");
    setError("");
    setResendTimer(30);
  };

  const handleBackToIdentifier = () => {
    setOtp("");
    setError("");
    setStep("IDENTIFIER");
  };

  const handleKioskConnection = () => {
    setScreen(SCREENS.KIOSK_CONNECT);
  };

  return (
    <div className="min-h-full bg-slate-50 text-slate-900 flex flex-col select-none">
      <main className="flex-1 px-4 py-6 sm:px-6 sm:py-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          {/* Brand */}
          <section className="text-center mb-6">
            <div className="w-16 h-16 rounded-3xl bg-teal-800 text-white flex items-center justify-center mx-auto shadow-md">
              <HeartPulse className="w-8 h-8" />
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight mt-4">
              AyushCare
            </h1>

            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              {isHindi
                ? "रोगी का मोबाइल स्वास्थ्य साथी"
                : "Patient Mobile Health Companion"}
            </p>
          </section>

          {/* Kiosk connection shortcut */}
          <button
            type="button"
            onClick={handleKioskConnection}
            className="w-full mb-4 p-4 rounded-2xl bg-teal-50 border border-teal-200 text-left flex items-center gap-3 hover:border-teal-400 active:scale-[0.99] transition cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-white text-teal-800 flex items-center justify-center shrink-0">
              <Smartphone className="w-4.5 h-4.5" />
            </div>

            <div className="min-w-0 flex-1">
              <p className="text-xs font-black text-teal-950">
                {isHindi
                  ? "क्या आप अस्पताल कियोस्क पर हैं?"
                  : "Are you at the hospital kiosk?"}
              </p>

              <p className="text-[10px] text-teal-800/70 mt-0.5">
                {isHindi
                  ? "QR कोड से वर्तमान सत्र से जुड़ें"
                  : "Connect to the current session using QR"}
              </p>
            </div>

            <ArrowRight className="w-4 h-4 text-teal-700 shrink-0" />
          </button>

          {/* Auth card */}
          <section className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-sm">
            {step === "IDENTIFIER" ? (
              <>
                <div className="mb-5">
                  <h2 className="text-lg font-black">
                    {isHindi
                      ? "अपने खाते में प्रवेश करें"
                      : "Sign in to your account"}
                  </h2>

                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    {isHindi
                      ? "अपनी पहचान के लिए नीचे दिए गए किसी एक विकल्प का उपयोग करें।"
                      : "Use one of the options below to verify your identity."}
                  </p>
                </div>

                {/* Method selector */}
                <div className="grid grid-cols-3 gap-2 mb-5">
                  <button
                    type="button"
                    onClick={() => {
                      setMethod(AUTH_METHODS.MOBILE);
                      setIdentifier("");
                      setError("");
                    }}
                    className={`min-h-[72px] rounded-xl border text-center transition cursor-pointer ${
                      method === AUTH_METHODS.MOBILE
                        ? "bg-teal-50 border-teal-600 text-teal-900"
                        : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                    }`}
                  >
                    <Smartphone className="w-4 h-4 mx-auto mb-1.5" />
                    <span className="text-[10px] font-black">
                      {isHindi ? "मोबाइल" : "Mobile"}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setMethod(AUTH_METHODS.ABHA);
                      setIdentifier("");
                      setError("");
                    }}
                    className={`min-h-[72px] rounded-xl border text-center transition cursor-pointer ${
                      method === AUTH_METHODS.ABHA
                        ? "bg-teal-50 border-teal-600 text-teal-900"
                        : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                    }`}
                  >
                    <HeartPulse className="w-4 h-4 mx-auto mb-1.5" />
                    <span className="text-[10px] font-black">
                      ABHA
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setMethod(AUTH_METHODS.AADHAAR);
                      setIdentifier("");
                      setError("");
                    }}
                    className={`min-h-[72px] rounded-xl border text-center transition cursor-pointer ${
                      method === AUTH_METHODS.AADHAAR
                        ? "bg-teal-50 border-teal-600 text-teal-900"
                        : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                    }`}
                  >
                    <Fingerprint className="w-4 h-4 mx-auto mb-1.5" />
                    <span className="text-[10px] font-black">
                      {isHindi ? "आधार" : "Aadhaar"}
                    </span>
                  </button>
                </div>

                {/* Identifier */}
                <label className="block">
                  <span className="text-xs font-black text-slate-700">
                    {getIdentifierLabel()}
                  </span>

                  <div className="relative mt-2">
                    <UserRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />

                    <input
                      type="text"
                      inputMode="numeric"
                      value={identifier}
                      onChange={(event) => {
                        setIdentifier(event.target.value);
                        setError("");
                      }}
                      placeholder={getIdentifierPlaceholder()}
                      className="w-full h-12 pl-10 pr-3 rounded-xl bg-white border border-slate-300 outline-none text-sm font-medium focus:border-teal-600 focus:ring-2 focus:ring-teal-100"
                    />
                  </div>
                </label>

                {error && (
                  <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-[11px] font-semibold">
                    {error}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleSendOtp}
                  className="w-full mt-5 min-h-[48px] rounded-xl bg-teal-800 text-white hover:bg-teal-900 active:scale-[0.99] transition flex items-center justify-center gap-2 text-sm font-black cursor-pointer"
                >
                  {isHindi
                    ? "OTP भेजें"
                    : "Send OTP"}
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="mt-4 flex items-start gap-2 text-[10px] text-slate-400 leading-relaxed">
                  <LockKeyhole className="w-3.5 h-3.5 shrink-0 mt-0.5" />

                  <span>
                    {isHindi
                      ? "डेमो में OTP सत्यापन सिम्युलेटेड है।"
                      : "OTP verification is simulated in this prototype."}
                  </span>
                </div>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={handleBackToIdentifier}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  {isHindi ? "वापस" : "Back"}
                </button>

                <div className="mt-4 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-800 flex items-center justify-center mx-auto">
                    <KeyRound className="w-6 h-6" />
                  </div>

                  <h2 className="text-lg font-black mt-3">
                    {isHindi
                      ? "OTP दर्ज करें"
                      : "Enter OTP"}
                  </h2>

                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    {isHindi
                      ? `${getIdentifierLabel()} पर भेजे गए 6 अंकों के OTP को दर्ज करें।`
                      : `Enter the 6-digit OTP sent to your ${getIdentifierLabel().toLowerCase()}.`}
                  </p>
                </div>

                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  autoFocus
                  value={otp}
                  onChange={(event) => {
                    const value =
                      event.target.value.replace(/\D/g, "");
                    setOtp(value);
                    setError("");
                  }}
                  placeholder="••••••"
                  className="w-full h-14 mt-6 rounded-2xl border border-slate-300 bg-white text-center text-2xl font-black tracking-[0.5em] outline-none focus:border-teal-600 focus:ring-2 focus:ring-teal-100"
                />

                {error && (
                  <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-[11px] font-semibold">
                    {error}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleVerifyOtp}
                  className="w-full mt-5 min-h-[48px] rounded-xl bg-teal-800 text-white hover:bg-teal-900 active:scale-[0.99] transition flex items-center justify-center gap-2 text-sm font-black cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {isHindi
                    ? "सत्यापित करें"
                    : "Verify"}
                </button>

                <button
                  type="button"
                  onClick={handleResend}
                  disabled={resendTimer > 0}
                  className="w-full mt-3 min-h-[42px] rounded-xl bg-white border border-slate-200 text-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed hover:bg-slate-50 flex items-center justify-center gap-2 text-xs font-bold cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />

                  {resendTimer > 0
                    ? isHindi
                      ? `OTP फिर भेजें (${resendTimer}s)`
                      : `Resend OTP (${resendTimer}s)`
                    : isHindi
                    ? "OTP फिर भेजें"
                    : "Resend OTP"}
                </button>

                <div className="mt-5 p-3 rounded-xl bg-blue-50 border border-blue-200">
                  <p className="text-[10px] text-blue-900 leading-relaxed">
                    <strong>
                      {isHindi
                        ? "डेमो OTP:"
                        : "Demo OTP:"}
                    </strong>{" "}
                    123456
                  </p>
                </div>
              </>
            )}
          </section>

          {/* Trust note */}
          <div className="mt-4 flex items-start gap-2.5 px-2">
            <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />

            <p className="text-[10px] text-slate-500 leading-relaxed">
              {isHindi
                ? "आपकी पहचान सत्यापन के बाद ही मोबाइल स्वास्थ्य अनुभव तक पहुंच मिलती है।"
                : "Identity verification is required before accessing the mobile health experience."}
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AuthScreen;