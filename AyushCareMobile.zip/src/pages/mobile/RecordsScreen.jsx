import React, { useMemo } from "react";
import {
  FileText,
  UploadCloud,
  Clock3,
  CalendarDays,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
  Building2,
  FileSpreadsheet,
  FolderHeart,
  Stethoscope,
  RotateCcw,
  Lock,
  Search,
  X,
} from "lucide-react";

import useMobileStore, { SCREENS } from "../../store/useMobileStore";
import MobileHeader from "../../components/mobile/MobileHeader";
import BottomNavBar from "../../components/mobile/BottomNavBar";
import useLanguage from "../../i18n/translations";

const CATEGORY_META = {
  prescription: {
    icon: FileText,
  },
  lab_report: {
    icon: FileSpreadsheet,
  },
  discharge_summary: {
    icon: Building2,
  },
  other: {
    icon: FolderHeart,
  },
};

const STATUS_META = {
  UPLOADED: {
    icon: UploadCloud,
  },
  CONFIRMED: {
    icon: CheckCircle2,
  },
  NEEDS_REVIEW: {
    icon: AlertCircle,
  },
  PROCESSING: {
    icon: Clock3,
  },
  PROCESSED: {
    icon: CheckCircle2,
  },
  FAILED: {
    icon: AlertCircle,
  },
};

const getRecordTypeLabel = (record, isHindi) => {
  if (isHindi) {
    switch (record?.type) {
      case "prescription":
        return "पर्चा";
      case "lab_report":
        return "लैब रिपोर्ट";
      case "discharge_summary":
        return "डिस्चार्ज सारांश";
      default:
        return record?.typeLabel || "अन्य रिकॉर्ड";
    }
  }

  return (
    record?.typeLabel ||
    {
      prescription: "Prescription",
      lab_report: "Lab Report",
      discharge_summary: "Discharge Summary",
      other: "Other",
    }[record?.type] ||
    "Medical Record"
  );
};

const getRecordDate = (record) =>
  record?.displayDate ||
  record?.date ||
  record?.createdAt ||
  "Date unavailable";

const getRecordSource = (record) =>
  record?.source ||
  record?.clinic ||
  record?.hospital ||
  "Healthcare facility";

const getStatusLabel = (status, isHindi) => {
  switch (status) {
    case "UPLOADED":
      return isHindi ? "अपलोड किया गया" : "Uploaded";
    case "CONFIRMED":
      return isHindi ? "सत्यापित" : "Confirmed";
    case "NEEDS_REVIEW":
      return isHindi ? "समीक्षा आवश्यक" : "Needs Review";
    case "PROCESSING":
      return isHindi ? "प्रक्रिया जारी" : "Processing";
    case "PROCESSED":
      return isHindi ? "प्रसंस्कृत" : "Processed";
    case "FAILED":
      return isHindi ? "विफल" : "Failed";
    default:
      return isHindi ? "प्रसंस्कृत" : "Processed";
  }
};

const StatusBadge = ({ status, isHindi }) => {
  const meta = STATUS_META[status] || STATUS_META.PROCESSED;
  const Icon = meta.icon;

  const styles = {
    UPLOADED:
      "bg-slate-100 text-slate-700 border-slate-300",
    CONFIRMED:
      "bg-teal-50 text-teal-800 border-teal-200",
    NEEDS_REVIEW:
      "bg-amber-50 text-amber-900 border-amber-300",
    PROCESSING:
      "bg-blue-50 text-blue-800 border-blue-200",
    PROCESSED:
      "bg-emerald-50 text-emerald-800 border-emerald-200",
    FAILED:
      "bg-rose-50 text-rose-800 border-rose-200",
  };

  const iconStyles = {
    UPLOADED: "text-slate-500",
    CONFIRMED: "text-teal-700",
    NEEDS_REVIEW: "text-amber-600",
    PROCESSING: "text-blue-600 animate-spin",
    PROCESSED: "text-emerald-600",
    FAILED: "text-rose-600",
  };

  return (
    <span
      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full border text-[10px] font-bold whitespace-nowrap ${
        styles[status] || styles.PROCESSED
      }`}
    >
      <Icon
        className={`w-3 h-3 ${
          iconStyles[status] || iconStyles.PROCESSED
        }`}
      />
      <span>{getStatusLabel(status, isHindi)}</span>
    </span>
  );
};

const CategoryCard = ({
  title,
  count,
  icon: Icon,
  selected,
  onClick,
  isHindi,
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`min-h-[104px] p-3.5 rounded-2xl border text-left transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between ${
        selected
          ? "bg-teal-50 border-teal-700 ring-1 ring-teal-600/20 shadow-xs"
          : "bg-white border-slate-200 hover:border-slate-300 shadow-2xs"
      }`}
    >
      <div className="flex items-center justify-between">
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center ${
            selected
              ? "bg-teal-800 text-white"
              : "bg-slate-100 text-slate-700"
          }`}
        >
          <Icon className="w-4 h-4" />
        </div>

        <span
          className={`min-w-7 px-2 py-1 rounded-full text-xs font-black text-center ${
            selected
              ? "bg-teal-800 text-white"
              : "bg-slate-100 text-slate-700"
          }`}
        >
          {count}
        </span>
      </div>

      <div className="mt-2">
        <p
          className={`text-xs font-bold leading-tight ${
            selected ? "text-teal-950" : "text-slate-800"
          }`}
        >
          {title}
        </p>

        <p className="text-[10px] text-slate-400 mt-1">
          {count} {isHindi ? "रिकॉर्ड" : count === 1 ? "record" : "records"}
        </p>
      </div>
    </button>
  );
};

const RecordCard = ({ record, onOpen, isHindi }) => {
  const typeLabel = getRecordTypeLabel(record, isHindi);
  const date = getRecordDate(record);
  const source = getRecordSource(record);

  const pages =
    Array.isArray(record?.pages) && record.pages.length > 0
      ? record.pages.length
      : Number(record?.totalPages || 0);

  const extraction =
    record?.extractedInformation ||
    record?.extraction ||
    record?.extractedData ||
    {};

  const medicines = Array.isArray(extraction?.medicines)
    ? extraction.medicines
    : [];

  const investigations = Array.isArray(extraction?.investigations)
    ? extraction.investigations
    : [];

  const entityCount = medicines.length + investigations.length;

  return (
    <button
      type="button"
      onClick={() => onOpen(record)}
      className="w-full p-4 rounded-2xl bg-white border border-slate-200 hover:border-teal-600/40 hover:shadow-md active:scale-[0.99] transition-all text-left cursor-pointer shadow-2xs"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center px-2 py-1 rounded-lg bg-teal-50 text-teal-800 border border-teal-200 text-[10px] font-black uppercase tracking-wide">
              {typeLabel}
            </span>

            {pages > 1 && (
              <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 border border-slate-200 px-2 py-1 rounded-lg">
                {pages} {isHindi ? "पृष्ठ" : "pages"}
              </span>
            )}
          </div>

          <h4 className="mt-2.5 text-sm sm:text-base font-black text-slate-900 leading-snug line-clamp-2">
            {record?.title || (isHindi ? "चिकित्सीय रिकॉर्ड" : "Medical Record")}
          </h4>
        </div>

        <ChevronRight className="w-5 h-5 text-slate-400 shrink-0 mt-1" />
      </div>

      <div className="mt-3 flex items-center gap-2 flex-wrap text-[11px] text-slate-500">
        <span className="inline-flex items-center gap-1">
          <CalendarDays className="w-3.5 h-3.5 text-slate-400" />
          {date}
        </span>

        <span>·</span>

        <span className="inline-flex items-center gap-1 min-w-0">
          <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="truncate max-w-[180px]">{source}</span>
        </span>
      </div>

      {entityCount > 0 && (
        <div className="mt-3 flex items-center gap-2 text-[10px] text-slate-500">
          <span className="px-2 py-1 rounded-lg bg-slate-50 border border-slate-200">
            {entityCount}{" "}
            {isHindi ? "जानकारी निकाली गई" : "extracted items"}
          </span>
        </div>
      )}

      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
        <StatusBadge
          status={record?.status}
          isHindi={isHindi}
        />

        <span className="text-[10px] font-bold text-teal-800">
          {isHindi ? "विवरण देखें" : "View details"}
        </span>
      </div>
    </button>
  );
};

export const RecordsScreen = () => {
  const {
    medicalRecords,
    setSelectedMedicalRecord,
    selectedRecordCategory,
    setSelectedRecordCategory,
    setScreen,
    prevScreen,
    isHealthHistoryLocked,
  } = useMobileStore();

  const { t, isHindi } = useLanguage();

  const [searchQuery, setSearchQuery] = React.useState("");

  const records = Array.isArray(medicalRecords) ? medicalRecords : [];

  const categoryCounts = useMemo(() => {
    const counts = {
      prescription: 0,
      lab_report: 0,
      discharge_summary: 0,
      other: 0,
    };

    records.forEach((record) => {
      if (counts[record?.type] !== undefined) {
        counts[record.type] += 1;
      } else {
        counts.other += 1;
      }
    });

    return counts;
  }, [records]);

  const categories = [
    {
      id: "prescription",
      title: t("records_cat_prescription"),
      count: categoryCounts.prescription,
      icon: CATEGORY_META.prescription.icon,
    },
    {
      id: "lab_report",
      title: t("records_cat_lab_report"),
      count: categoryCounts.lab_report,
      icon: CATEGORY_META.lab_report.icon,
    },
    {
      id: "discharge_summary",
      title: t("records_cat_discharge"),
      count: categoryCounts.discharge_summary,
      icon: CATEGORY_META.discharge_summary.icon,
    },
    {
      id: "other",
      title: isHindi ? "अन्य चिकित्सीय रिकॉर्ड" : "Other Medical Records",
      count: categoryCounts.other,
      icon: CATEGORY_META.other.icon,
    },
  ];

  const filteredRecords = useMemo(() => {
    let result = records;

    if (selectedRecordCategory !== "ALL") {
      result = result.filter((record) => {
        if (selectedRecordCategory === "other") {
          return (
            record?.type !== "prescription" &&
            record?.type !== "lab_report" &&
            record?.type !== "discharge_summary"
          );
        }

        return record?.type === selectedRecordCategory;
      });
    }

    const query = searchQuery.trim().toLowerCase();

    if (query) {
      result = result.filter((record) => {
        const searchable = [
          record?.title,
          record?.type,
          record?.typeLabel,
          record?.source,
          record?.doctor,
          record?.clinic,
          record?.hospital,
          record?.displayDate,
          record?.date,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();

        return searchable.includes(query);
      });
    }

    return result;
  }, [records, selectedRecordCategory, searchQuery]);

  const groupedRecords = useMemo(() => {
    const groups = {};

    filteredRecords.forEach((record) => {
      const group =
        record?.monthGroup ||
        record?.displayMonth ||
        (isHindi ? "हाल ही में" : "Recent");

      if (!groups[group]) {
        groups[group] = [];
      }

      groups[group].push(record);
    });

    return groups;
  }, [filteredRecords, isHindi]);

  const handleOpenDocument = (record) => {
    setSelectedMedicalRecord(record);
    setScreen(SCREENS.DOCUMENT_DETAILS);
  };

  const handleCategoryClick = (categoryId) => {
    setSelectedRecordCategory(
      selectedRecordCategory === categoryId ? "ALL" : categoryId
    );
  };

  const clearSearch = () => {
    setSearchQuery("");
  };

  return (
    <div className="min-h-full flex flex-col bg-slate-50 text-slate-900 select-none">
      <MobileHeader
        title={t("records_title")}
        showBack={true}
        onBack={prevScreen}
      />

      <main className="flex-1 px-4 sm:px-6 py-4 sm:py-6 max-w-md md:max-w-2xl lg:max-w-3xl mx-auto w-full space-y-5">
        {/* Header */}
        <section className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              {t("records_title")}
            </h1>

            <p className="text-xs sm:text-sm text-slate-500 mt-1 leading-relaxed">
              {isHindi
                ? "आपके पर्चे, जांच रिपोर्ट और अन्य चिकित्सीय दस्तावेज़।"
                : "Your prescriptions, reports and other medical documents."}
            </p>
          </div>

          {isHealthHistoryLocked && (
            <span className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-50 text-amber-900 border border-amber-300">
              <Lock className="w-3 h-3" />
              {isHindi ? "साझाकरण प्रतिबंधित" : "Sharing restricted"}
            </span>
          )}
        </section>

        {/* Upload CTA */}
        <section className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-teal-800 to-teal-950 text-white shadow-md">
          <div className="flex items-center justify-between gap-4">
            <div className="min-w-0">
              <span className="inline-flex text-[10px] font-black uppercase tracking-wider text-teal-100 bg-teal-700/60 px-2 py-1 rounded-lg">
                {isHindi ? "डिजिटाइज़ करें" : "Digitize"}
              </span>

              <h2 className="text-base sm:text-lg font-black mt-2 leading-tight">
                {isHindi
                  ? "नया चिकित्सीय दस्तावेज़ जोड़ें"
                  : "Add a medical document"}
              </h2>

              <p className="text-xs text-teal-100/90 mt-1.5 leading-relaxed">
                {isHindi
                  ? "पर्चा स्कैन करें या उपलब्ध दस्तावेज़ प्रक्रिया शुरू करें।"
                  : "Scan a prescription or start the document workflow."}
              </p>
            </div>

            <button
              type="button"
              onClick={() => setScreen(SCREENS.M2)}
              className="shrink-0 h-11 px-4 rounded-2xl bg-white text-teal-950 font-bold text-xs flex items-center gap-2 hover:bg-teal-50 active:scale-95 transition cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              {isHindi ? "अपलोड" : "Upload"}
            </button>
          </div>
        </section>

        {/* Search */}
        <section>
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />

            <input
              type="search"
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder={
                isHindi
                  ? "रिकॉर्ड खोजें..."
                  : "Search records..."
              }
              className="w-full h-12 pl-10 pr-10 rounded-2xl bg-white border border-slate-200 text-sm font-medium outline-none focus:border-teal-600 focus:ring-2 focus:ring-teal-100 shadow-2xs"
            />

            {searchQuery && (
              <button
                type="button"
                onClick={clearSearch}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                aria-label={isHindi ? "खोज साफ करें" : "Clear search"}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </section>

        {/* Categories */}
        <section className="space-y-2.5">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-500">
              {isHindi ? "श्रेणियां" : "Categories"}
            </h2>

            {selectedRecordCategory !== "ALL" && (
              <button
                type="button"
                onClick={() => setSelectedRecordCategory("ALL")}
                className="inline-flex items-center gap-1 text-xs font-bold text-teal-800 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                {isHindi ? "सभी" : "Show all"}
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {categories.map((category) => (
              <CategoryCard
                key={category.id}
                title={category.title}
                count={category.count}
                icon={category.icon}
                selected={selectedRecordCategory === category.id}
                onClick={() => handleCategoryClick(category.id)}
                isHindi={isHindi}
              />
            ))}
          </div>
        </section>

        {/* Records heading */}
        <section className="space-y-3">
          <div className="flex items-center justify-between gap-3 px-1">
            <div>
              <h2 className="text-xs font-black uppercase tracking-wider text-slate-500">
                {selectedRecordCategory === "ALL"
                  ? isHindi
                    ? "सभी रिकॉर्ड"
                    : "All records"
                  : categories.find(
                      (category) =>
                        category.id === selectedRecordCategory
                    )?.title ||
                    (isHindi ? "फ़िल्टर किए गए रिकॉर्ड" : "Filtered records")}
              </h2>

              <p className="text-[11px] text-slate-400 mt-0.5">
                {filteredRecords.length}{" "}
                {isHindi
                  ? "रिकॉर्ड"
                  : filteredRecords.length === 1
                  ? "record"
                  : "records"}
              </p>
            </div>

            <button
              type="button"
              onClick={() => setScreen(SCREENS.M7)}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-800 cursor-pointer"
            >
              <Clock3 className="w-3.5 h-3.5" />
              {isHindi ? "समयरेखा" : "Timeline"}
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {filteredRecords.length === 0 ? (
            <div className="p-8 rounded-3xl bg-white border border-slate-200 text-center shadow-xs">
              <div className="w-14 h-14 rounded-2xl bg-teal-50 border border-teal-200 text-teal-800 flex items-center justify-center mx-auto">
                {searchQuery ? (
                  <Search className="w-7 h-7" />
                ) : (
                  <FileText className="w-7 h-7" />
                )}
              </div>

              <h3 className="mt-4 text-base font-black text-slate-900">
                {searchQuery
                  ? isHindi
                    ? "कोई रिकॉर्ड नहीं मिला"
                    : "No matching records"
                  : isHindi
                  ? "अभी कोई रिकॉर्ड नहीं है"
                  : "No medical records yet"}
              </h3>

              <p className="mt-1.5 text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                {searchQuery
                  ? isHindi
                    ? "खोज शब्द बदलकर फिर प्रयास करें।"
                    : "Try a different search term."
                  : isHindi
                  ? "आपके अपलोड और सत्यापित किए गए दस्तावेज़ यहां दिखाई देंगे।"
                  : "Uploaded and confirmed documents will appear here."}
              </p>

              {!searchQuery && (
                <button
                  type="button"
                  onClick={() => setScreen(SCREENS.M2)}
                  className="mt-4 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-800 text-white text-xs font-bold hover:bg-teal-900 active:scale-95 transition cursor-pointer"
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  {isHindi ? "दस्तावेज़ अपलोड करें" : "Upload document"}
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-5">
              {Object.entries(groupedRecords).map(
                ([groupName, groupRecords]) => (
                  <div key={groupName} className="space-y-2.5">
                    <div className="flex items-center gap-2 px-1">
                      <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                        {groupName}
                      </span>
                      <div className="flex-1 h-px bg-slate-200" />
                    </div>

                    <div className="space-y-2.5">
                      {groupRecords.map((record) => (
                        <RecordCard
                          key={record?.id}
                          record={record}
                          onOpen={handleOpenDocument}
                          isHindi={isHindi}
                        />
                      ))}
                    </div>
                  </div>
                )
              )}
            </div>
          )}
        </section>
      </main>

      <BottomNavBar />
    </div>
  );
};

export default RecordsScreen; 