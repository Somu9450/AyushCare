import React from "react";
import {
  Home,
  CalendarDays,
  FileText,
  UserRound,
} from "lucide-react";

import useMobileStore, {
  SCREENS,
} from "../../store/useMobileStore";

/* ========================================================================== */
/* BOTTOM NAVIGATION                                                          */
/* ========================================================================== */

const BottomNavBar = () => {
  const {
    currentScreen,
    setScreen,
    activeNavTab,
    setActiveNavTab,
  } = useMobileStore();

  const {
    selectedLanguage,
  } = useMobileStore();

  const isHindi =
    selectedLanguage === "hi";

  const navItems = [
    {
      id: "home",

      label:
        isHindi
          ? "होम"
          : "Home",

      icon: Home,

      screen:
        SCREENS.M1,
    },

    {
      id: "visits",

      label:
        isHindi
          ? "मुलाकातें"
          : "Visits",

      icon: CalendarDays,

      screen:
        SCREENS.VISITS,

      badge:
        isHindi
          ? "आज"
          : "Today",
    },

    {
      id: "records",

      label:
        isHindi
          ? "रिकॉर्ड्स"
          : "Records",

      icon: FileText,

      screen:
        SCREENS.RECORDS,
    },

    {
      id: "more",

      label:
        isHindi
          ? "अधिक"
          : "More",

      icon: UserRound,

      screen:
        SCREENS.MORE,
    },
  ];

  /* ------------------------------------------------------------------------ */
  /* ACTIVE DOMAIN                                                            */
  /* ------------------------------------------------------------------------ */

  const getActiveDomain =
    () => {
      /*
       * Home domain
       */
      if (
        currentScreen ===
        SCREENS.M1
      ) {
        return "home";
      }

      /*
       * Visits domain
       */
      if (
        currentScreen ===
          SCREENS.VISITS ||
        currentScreen ===
          SCREENS.VISIT_DETAILS ||
        currentScreen ===
          SCREENS.APPOINTMENTS
      ) {
        return "visits";
      }

      /*
       * Records domain
       */
      if (
        currentScreen ===
          SCREENS.RECORDS ||
        currentScreen ===
          SCREENS.DOCUMENT_DETAILS
      ) {
        return "records";
      }

      /*
       * More domain
       */
      if (
        currentScreen ===
          SCREENS.MORE ||
        currentScreen ===
          SCREENS.PRIVACY ||
        currentScreen ===
          SCREENS.CONSENT_DETAILS ||
        currentScreen ===
          SCREENS.PROFILE ||
        currentScreen ===
          SCREENS.SETTINGS ||
        currentScreen ===
          SCREENS.ABOUT ||
        currentScreen ===
          SCREENS.KIOSK_SESSION
      ) {
        return "more";
      }

      /*
       * M2-M9 are a temporary workflow.
       *
       * They deliberately do NOT become
       * an active primary navigation tab.
       */
      return null;
    };

  const activeDomain =
    getActiveDomain();

  /* ------------------------------------------------------------------------ */
  /* NAVIGATION                                                               */
  /* ------------------------------------------------------------------------ */

  const handleNav = (
    item
  ) => {
    if (
      currentScreen ===
      item.screen
    ) {
      return;
    }

    setActiveNavTab(
      item.id
    );

    setScreen(
      item.screen
    );
  };

  /* ------------------------------------------------------------------------ */
  /* VISIBILITY                                                               */
  /* ------------------------------------------------------------------------ */

  /*
   * The bottom nav should not interfere
   * with the document capture workflow.
   *
   * M2-M9 are full-screen workflow pages.
   */
  const isDocumentWorkflow =
    [
      SCREENS.M2,
      SCREENS.M3,
      SCREENS.M4,
      SCREENS.M5,
      SCREENS.M6,
      SCREENS.M7,
      SCREENS.M8,
      SCREENS.M9,
    ].includes(
      currentScreen
    );

  if (isDocumentWorkflow) {
    return null;
  }

  /*
   * Authentication has its own navigation.
   */
  if (
    currentScreen ===
    SCREENS.AUTH
  ) {
    return null;
  }

  return (
    <nav
      aria-label={
        isHindi
          ? "मुख्य नेविगेशन"
          : "Main Navigation"
      }
      className="
        shrink-0
        w-full
        px-4
        pt-2
        pb-safe
        bg-white
        border-t
        border-slate-200/90
        shadow-[0_-4px_20px_rgba(0,0,0,0.04)]
        z-30
      "
    >
      <div
        className="
          max-w-md
          md:max-w-2xl
          lg:max-w-4xl
          mx-auto
          flex
          items-center
          justify-around
          gap-1
        "
      >
        {navItems.map(
          (item) => {
            const Icon =
              item.icon;

            const isActive =
              activeDomain ===
              item.id;

            /*
             * Fallback to activeNavTab
             * only when the current screen
             * is not a known nested screen.
             */
            const visuallyActive =
              isActive ||
              (!activeDomain &&
                activeNavTab ===
                  item.id);

            return (
              <button
                key={item.id}
                type="button"
                onClick={() =>
                  handleNav(
                    item
                  )
                }
                aria-label={
                  item.label
                }
                aria-current={
                  visuallyActive
                    ? "page"
                    : undefined
                }
                className={[
                  "flex-1",
                  "min-h-[54px]",
                  "py-1",
                  "px-2",
                  "rounded-2xl",
                  "flex",
                  "flex-col",
                  "items-center",
                  "justify-center",
                  "gap-1",
                  "transition-all",
                  "select-none",
                  "cursor-pointer",
                  "active:scale-95",
                  "relative",
                  visuallyActive
                    ? "text-teal-800 font-bold"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50 font-medium",
                ].join(" ")}
              >
                <div className="relative">
                  <Icon
                    aria-hidden="true"
                    className={[
                      "w-5 h-5",
                      "transition-transform",
                      visuallyActive
                        ? "scale-110 stroke-[2.4] text-teal-800"
                        : "stroke-[1.8]",
                    ].join(" ")}
                  />

                  {item.badge && (
                    <span
                      className="
                        absolute
                        -top-1.5
                        -right-3.5
                        bg-amber-500
                        text-white
                        font-bold
                        text-[9px]
                        px-1
                        py-0.5
                        rounded-full
                        uppercase
                        tracking-wider
                        leading-none
                      "
                    >
                      {item.badge}
                    </span>
                  )}
                </div>

                <span
                  className={[
                    "text-[11px]",
                    "leading-tight",
                    "tracking-tight",
                    "transition-colors",
                    visuallyActive
                      ? "text-teal-800 font-extrabold"
                      : "text-slate-500",
                  ].join(" ")}
                >
                  {item.label}
                </span>

                {visuallyActive && (
                  <span
                    aria-hidden="true"
                    className="
                      w-1.5
                      h-1.5
                      rounded-full
                      bg-teal-800
                      -mb-1
                    "
                  />
                )}
              </button>
            );
          }
        )}
      </div>
    </nav>
  );
};

export default BottomNavBar;