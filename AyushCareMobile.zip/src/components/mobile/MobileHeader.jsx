import React from "react";
import { ArrowLeft, CheckCircle2, Link2Off } from "lucide-react";
import useMobileStore, { SCREENS } from "../../store/useMobileStore";
import useLanguage from "../../i18n/translations";

export const MobileHeader = ({
  title,
  showBack = true,
  onBack,
  rightElement,
  subtitle,
  dark = false,
  showLanguage = true,
  showSessionStatus = true,
}) => {
  const {
    currentScreen,
    prevScreen,
    selectedLanguage,
    setSelectedLanguage,
    kioskSession,
  } = useMobileStore();

  const { isHindi } = useLanguage();

  const handleBack = () => {
    if (onBack) {
      onBack();
      return;
    }

    prevScreen();
  };

  const rootScreens = new Set([SCREENS.AUTH, SCREENS.M1, SCREENS.MORE]);

  const canGoBack = showBack && !rootScreens.has(currentScreen);

  const sessionConnected =
    Boolean(kioskSession) &&
    (kioskSession.connected === true ||
      kioskSession.isConnected === true ||
      kioskSession.status === "CONNECTED" ||
      kioskSession.status === "ACTIVE");

  const toggleLanguage = () => {
    setSelectedLanguage(selectedLanguage === "hi" ? "en" : "hi");
  };

  const headerTitle =
    title ||
    (currentScreen === SCREENS.M1 ? (isHindi ? "होम" : "Home") : "AYUSHCARE");

  return (
    <header
      className={`w-full shrink-0 border-b transition-colors ${
        dark
          ? "border-slate-800 bg-slate-950 text-white"
          : "border-slate-200 bg-white text-slate-900"
      }`}
    >
      <div className="mx-auto flex min-h-[60px] max-w-5xl items-center justify-between gap-3 px-4 pt-safe sm:min-h-[68px] sm:px-5">
        <div className="flex min-w-0 items-center gap-2.5">
          {canGoBack && (
            <button
              type="button"
              onClick={handleBack}
              aria-label={isHindi ? "पीछे जाएँ" : "Go back"}
              className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition active:scale-95 ${
                dark
                  ? "text-slate-200 hover:bg-slate-800 active:bg-slate-700"
                  : "text-slate-700 hover:bg-slate-100 active:bg-slate-200"
              }`}
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
          )}

          <div className="min-w-0">
            <h1
              className={`truncate text-base font-bold leading-tight ${
                dark ? "text-white" : "text-slate-900"
              }`}
            >
              {headerTitle}
            </h1>

            {subtitle && (
              <p
                className={`mt-0.5 truncate text-xs leading-tight ${
                  dark ? "text-slate-400" : "text-slate-500"
                }`}
              >
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {rightElement ? (
          <div className="flex shrink-0 items-center">{rightElement}</div>
        ) : (
          <div className="flex shrink-0 items-center gap-2">
            {showLanguage && (
              <button
                type="button"
                onClick={toggleLanguage}
                aria-label={isHindi ? "Switch to English" : "हिन्दी में बदलें"}
                title={isHindi ? "Switch to English" : "हिन्दी में बदलें"}
                className={`min-h-[36px] rounded-full border px-2.5 text-xs font-bold transition active:scale-95 ${
                  dark
                    ? "border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800"
                    : "border-slate-300 bg-slate-50 text-slate-700 hover:bg-slate-100"
                }`}
              >
                {isHindi ? "EN" : "हिन्दी"}
              </button>
            )}

            {showSessionStatus && sessionConnected && (
              <div
                className={`flex min-h-[36px] items-center gap-1.5 rounded-full border px-2.5 text-[10px] font-bold ${
                  dark
                    ? "border-emerald-800 bg-emerald-950/50 text-emerald-300"
                    : "border-emerald-200 bg-emerald-50 text-emerald-800"
                }`}
                aria-label={
                  isHindi ? "कियोस्क से जुड़ा हुआ" : "Connected to kiosk"
                }
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">
                  {isHindi ? "कियोस्क जुड़ा है" : "Kiosk connected"}
                </span>
              </div>
            )}

            {showSessionStatus && kioskSession && !sessionConnected && (
              <div
                className={`flex min-h-[36px] items-center gap-1.5 rounded-full border px-2.5 text-[10px] font-bold ${
                  dark
                    ? "border-slate-700 bg-slate-900 text-slate-400"
                    : "border-slate-200 bg-slate-50 text-slate-500"
                }`}
              >
                <Link2Off className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">
                  {isHindi ? "कियोस्क डिस्कनेक्ट" : "Not connected"}
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default MobileHeader;
