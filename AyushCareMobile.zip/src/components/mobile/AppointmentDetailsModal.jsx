import React from "react";
import {
  CalendarDays,
  Clock3,
  HeartPulse,
  MapPin,
  ShieldCheck,
  Stethoscope,
  UserRound,
  X,
} from "lucide-react";
import useMobileStore from "../../store/useMobileStore";
import useLanguage from "../../i18n/translations";

const valueOrDash = (value) =>
  value === null || value === undefined || value === ""
    ? "—"
    : String(value);

const getStatusText = (status, isHindi) => {
  const normalized = String(status || "").toUpperCase();

  if (normalized === "IN_QUEUE") {
    return isHindi ? "कतार में" : "In queue";
  }

  if (normalized === "CONFIRMED") {
    return isHindi ? "पुष्ट" : "Confirmed";
  }

  if (
    normalized === "COMPLETED" ||
    normalized === "PAST" ||
    normalized === "DONE"
  ) {
    return isHindi ? "पूर्ण" : "Completed";
  }

  if (normalized === "CANCELLED") {
    return isHindi ? "रद्द" : "Cancelled";
  }

  return status
    ? valueOrDash(status)
    : isHindi
      ? "स्थिति उपलब्ध नहीं"
      : "Status unavailable";
};

export const AppointmentDetailsModal = () => {
  const {
    selectedAppointment,
    setSelectedAppointment,
  } = useMobileStore();

  const { isHindi } = useLanguage();

  if (!selectedAppointment) return null;

  const appointment = selectedAppointment;

  const closeModal = () => {
    setSelectedAppointment(null);
  };

  const doctorName =
    appointment.doctorName ||
    appointment.doctor ||
    appointment.clinician ||
    "";

  const department =
    appointment.department ||
    appointment.specialty ||
    appointment.departmentName ||
    "";

  const hospital =
    appointment.hospitalName ||
    appointment.facility ||
    appointment.hospital ||
    "";

  const location =
    appointment.location ||
    appointment.room ||
    appointment.roomNumber ||
    "";

  const date =
    appointment.date ||
    appointment.appointmentDate ||
    "";

  const time =
    appointment.timeSlot ||
    appointment.time ||
    appointment.appointmentTime ||
    "";

  const token =
    appointment.tokenNumber ||
    appointment.token ||
    "";

  const queuePosition =
    appointment.queuePosition ??
    appointment.position ??
    null;

  const waitTime =
    appointment.estimatedWaitTime ||
    appointment.waitTime ||
    "";

  const symptoms =
    appointment.symptomsSummary ||
    appointment.symptoms ||
    appointment.complaint ||
    "";

  const diagnosis =
    appointment.diagnosis ||
    appointment.clinicalSummary ||
    "";

  const summary =
    appointment.summary ||
    appointment.notes ||
    "";

  const vitals = appointment.vitalsRecorded || appointment.vitals || null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      role="presentation"
      onClick={closeModal}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="appointment-details-title"
        className="flex max-h-[92vh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl border border-slate-200 bg-white shadow-2xl sm:rounded-3xl"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 bg-slate-50 px-4 py-4 sm:px-5">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-800 text-white">
              <CalendarDays className="h-5 w-5" />
            </div>

            <div className="min-w-0">
              <h2
                id="appointment-details-title"
                className="truncate text-base font-bold text-slate-900"
              >
                {isHindi ? "अपॉइंटमेंट विवरण" : "Appointment Details"}
              </h2>

              {token && (
                <p className="mt-0.5 text-xs text-slate-500">
                  {isHindi ? "टोकन" : "Token"}{" "}
                  <span className="font-bold text-teal-800">
                    {token}
                  </span>
                </p>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={closeModal}
            aria-label={isHindi ? "बंद करें" : "Close"}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 transition hover:bg-slate-100 active:scale-95"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-y-auto px-4 py-4 sm:px-5">
          <div className="space-y-4">
            <section className="rounded-2xl border border-teal-200 bg-teal-50 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <span className="block text-[10px] font-black uppercase tracking-wider text-teal-700">
                    {isHindi ? "स्थिति" : "Status"}
                  </span>

                  <p className="mt-1 text-sm font-black text-slate-900">
                    {getStatusText(appointment.status, isHindi)}
                  </p>

                  {queuePosition !== null &&
                    String(appointment.status || "").toUpperCase() ===
                      "IN_QUEUE" && (
                      <p className="mt-1 text-xs text-slate-600">
                        {isHindi
                          ? `आपसे पहले ${queuePosition} मरीज़`
                          : `${queuePosition} patients ahead of you`}
                      </p>
                    )}
                </div>

                {waitTime && (
                  <div className="flex shrink-0 items-center gap-1 rounded-full border border-teal-200 bg-white px-3 py-1.5 text-[10px] font-bold text-teal-900">
                    <Clock3 className="h-3.5 w-3.5" />
                    {waitTime}
                  </div>
                )}
              </div>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-4">
              <div className="mb-3 flex items-center gap-2">
                <Stethoscope className="h-4 w-4 text-teal-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  {isHindi ? "परामर्श जानकारी" : "Consultation"}
                </h3>
              </div>

              <div className="space-y-3">
                {doctorName && (
                  <div className="flex items-start gap-3">
                    <UserRound className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
                    <div>
                      <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        {isHindi ? "चिकित्सक" : "Clinician"}
                      </span>
                      <p className="text-xs font-semibold text-slate-800">
                        {doctorName}
                      </p>
                    </div>
                  </div>
                )}

                {department && (
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      {isHindi ? "विभाग" : "Department"}
                    </span>
                    <p className="text-xs font-semibold text-slate-800">
                      {department}
                    </p>
                  </div>
                )}

                {hospital && (
                  <div className="flex items-start gap-3">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
                    <div>
                      <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        {isHindi ? "स्थान" : "Facility"}
                      </span>
                      <p className="text-xs font-semibold text-slate-800">
                        {hospital}
                      </p>
                      {location && (
                        <p className="mt-0.5 text-[11px] text-slate-500">
                          {location}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {(date || time) && (
                  <div className="grid grid-cols-2 gap-3 border-t border-slate-100 pt-3">
                    <div>
                      <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        {isHindi ? "दिनांक" : "Date"}
                      </span>
                      <p className="mt-0.5 text-xs font-semibold text-slate-800">
                        {valueOrDash(date)}
                      </p>
                    </div>

                    <div>
                      <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        {isHindi ? "समय" : "Time"}
                      </span>
                      <p className="mt-0.5 text-xs font-semibold text-slate-800">
                        {valueOrDash(time)}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {vitals && (
              <section className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="mb-3 flex items-center gap-2">
                  <HeartPulse className="h-4 w-4 text-teal-700" />
                  <h3 className="text-sm font-bold text-slate-900">
                    {isHindi ? "दर्ज किए गए वाइटल्स" : "Recorded Vitals"}
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {[
                    ["BP", vitals.bp],
                    [isHindi ? "नाड़ी" : "Pulse", vitals.pulse],
                    [isHindi ? "तापमान" : "Temperature", vitals.temp || vitals.temperature],
                    ["SpO2", vitals.spo2 || vitals.spO2],
                  ].map(([label, value]) => (
                    <div
                      key={label}
                      className="rounded-xl border border-slate-200 bg-white p-2.5 text-center"
                    >
                      <span className="block text-[9px] font-bold uppercase text-slate-400">
                        {label}
                      </span>
                      <span className="mt-0.5 block text-xs font-bold text-slate-800">
                        {valueOrDash(value)}
                      </span>
                    </div>
                  ))}
                </div>

                <p className="mt-3 text-[10px] leading-relaxed text-slate-500">
                  {isHindi
                    ? "ये मान इस अपॉइंटमेंट के रिकॉर्ड से दिखाए गए हैं।"
                    : "These values are shown from the appointment record."}
                </p>
              </section>
            )}

            {symptoms && (
              <section className="rounded-2xl border border-slate-200 bg-white p-4">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {isHindi ? "रिपोर्ट की गई समस्या" : "Reported complaint"}
                </span>
                <p className="mt-1 text-xs font-semibold leading-relaxed text-slate-800">
                  {symptoms}
                </p>
              </section>
            )}

            {(diagnosis || summary) && (
              <section className="rounded-2xl border border-slate-200 bg-white p-4">
                {diagnosis && (
                  <>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      {isHindi
                        ? "क्लिनिकल जानकारी"
                        : "Clinical information"}
                    </span>
                    <p className="mt-1 text-sm font-bold text-slate-900">
                      {diagnosis}
                    </p>
                  </>
                )}

                {summary && (
                  <p
                    className={`text-xs leading-relaxed text-slate-600 ${
                      diagnosis ? "mt-2" : ""
                    }`}
                  >
                    {summary}
                  </p>
                )}
              </section>
            )}

            <section className="flex items-start gap-2 rounded-xl bg-slate-100 p-3 text-[11px] leading-relaxed text-slate-600">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal-700" />
              <span>
                {isHindi
                  ? "अपॉइंटमेंट की जानकारी आपके रिकॉर्ड में उपलब्ध जानकारी के आधार पर दिखाई जा रही है।"
                  : "Appointment information is shown from the information available in your record."}
              </span>
            </section>
          </div>
        </div>

        <div className="border-t border-slate-200 bg-slate-50 p-4">
          <button
            type="button"
            onClick={closeModal}
            className="min-h-[46px] w-full rounded-xl bg-teal-800 px-4 text-sm font-bold text-white transition hover:bg-teal-900 active:scale-[0.99]"
          >
            {isHindi ? "बंद करें" : "Close"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AppointmentDetailsModal;