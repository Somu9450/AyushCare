import React from "react";
import { Calendar, FileText, ImageOff } from "lucide-react";

const safeText = (value, fallback = "—") => {
  if (value === null || value === undefined || value === "") return fallback;
  return String(value);
};

const getDocumentLabel = (type, isHindi) => {
  const normalized = String(type || "").toLowerCase();

  if (
    normalized.includes("prescription") ||
    normalized.includes("rx")
  ) {
    return isHindi ? "प्रिस्क्रिप्शन" : "Prescription";
  }

  if (
    normalized.includes("lab") ||
    normalized.includes("report")
  ) {
    return isHindi ? "लैब रिपोर्ट" : "Lab Report";
  }

  if (normalized.includes("discharge")) {
    return isHindi ? "डिस्चार्ज सारांश" : "Discharge Summary";
  }

  return isHindi ? "चिकित्सा दस्तावेज़" : "Medical Document";
};

const getStatusLabel = (status, isHindi) => {
  const normalized = String(status || "").toLowerCase();

  if (normalized.includes("verified")) {
    return isHindi ? "क्लिनिकल रूप से सत्यापित" : "Clinician verified";
  }

  if (normalized.includes("review")) {
    return isHindi ? "समीक्षा आवश्यक" : "Review needed";
  }

  if (normalized.includes("extract")) {
    return isHindi ? "जानकारी निकाली गई" : "Information extracted";
  }

  return isHindi ? "दस्तावेज़ स्रोत" : "Document source";
};

export const DocumentPreview = ({
  documentName = "Medical document",
  documentType = "other",
  date = "",
  doctor = "",
  clinic = "",
  patientName = "",
  patientAge = "",
  patientGender = "",
  imageSrc = null,
  showFullDetails = true,
  status = "",
  extraction = null,
  isHindi = false,
  className = "",
}) => {
  if (imageSrc) {
    return (
      <div
        className={`w-full overflow-hidden rounded-2xl border border-slate-200 bg-slate-950 shadow-sm ${className}`}
      >
        <img
          src={imageSrc}
          alt={isHindi ? "दस्तावेज़ का पूर्वावलोकन" : "Document preview"}
          className="mx-auto block max-h-[420px] w-full object-contain"
          onError={(event) => {
            event.currentTarget.style.display = "none";
            const fallback = event.currentTarget.nextElementSibling;
            if (fallback) fallback.classList.remove("hidden");
          }}
        />

        <div className="hidden min-h-[220px] items-center justify-center px-6 text-center text-slate-300">
          <div>
            <ImageOff className="mx-auto mb-2 h-8 w-8" />
            <p className="text-sm font-semibold">
              {isHindi
                ? "दस्तावेज़ का पूर्वावलोकन उपलब्ध नहीं है"
                : "Document preview is unavailable"}
            </p>
          </div>
        </div>
      </div>
    );
  }

  const medicines =
    extraction?.medicines ||
    extraction?.medications ||
    extraction?.prescribedMedicines ||
    [];

  const diagnosis =
    extraction?.diagnosis ||
    extraction?.assessment ||
    extraction?.clinicalImpression ||
    "";

  const investigations =
    extraction?.investigations ||
    extraction?.tests ||
    extraction?.labTests ||
    [];

  const notes =
    extraction?.notes ||
    extraction?.instructions ||
    extraction?.doctorNotes ||
    "";

  const documentLabel = getDocumentLabel(documentType, isHindi);

  return (
    <div
      className={`relative w-full overflow-hidden rounded-2xl border border-slate-300 bg-white text-slate-800 shadow-sm ${className}`}
    >
      <div className="border-b border-slate-200 bg-slate-50 px-4 py-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal-800 text-white">
              <FileText className="h-4 w-4" />
            </div>

            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wider text-teal-700">
                {documentLabel}
              </p>

              <h3 className="truncate text-sm font-bold text-slate-900">
                {safeText(documentName)}
              </h3>

              {clinic && (
                <p className="mt-0.5 truncate text-[11px] text-slate-500">
                  {clinic}
                </p>
              )}
            </div>
          </div>

          {date && (
            <div className="flex shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-[10px] font-semibold text-slate-600">
              <Calendar className="h-3 w-3" />
              <span>{date}</span>
            </div>
          )}
        </div>
      </div>

      {(patientName || patientAge || patientGender) && (
        <div className="mx-4 mt-3 grid grid-cols-2 gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3">
          {patientName && (
            <div className="col-span-2">
              <span className="block text-[9px] font-bold uppercase tracking-wider text-slate-400">
                {isHindi ? "मरीज़ का नाम" : "Patient"}
              </span>
              <span className="block truncate text-xs font-bold text-slate-900">
                {patientName}
              </span>
            </div>
          )}

          {patientAge && (
            <div>
              <span className="block text-[9px] font-bold uppercase tracking-wider text-slate-400">
                {isHindi ? "उम्र" : "Age"}
              </span>
              <span className="text-xs font-semibold text-slate-700">
                {patientAge}
              </span>
            </div>
          )}

          {patientGender && (
            <div>
              <span className="block text-[9px] font-bold uppercase tracking-wider text-slate-400">
                {isHindi ? "लिंग" : "Gender"}
              </span>
              <span className="text-xs font-semibold text-slate-700">
                {patientGender}
              </span>
            </div>
          )}
        </div>
      )}

      <div className="px-4 py-4">
        {doctor && (
          <div className="mb-4">
            <span className="block text-[9px] font-bold uppercase tracking-wider text-slate-400">
              {isHindi ? "चिकित्सक" : "Clinician"}
            </span>
            <p className="mt-0.5 text-xs font-bold text-slate-900">
              {doctor}
            </p>
          </div>
        )}

        {medicines.length > 0 && (
          <section className="mb-4">
            <div className="mb-2 flex items-center gap-2">
              <span className="text-lg font-serif font-black text-teal-800">
                ℞
              </span>
              <h4 className="text-xs font-bold text-slate-800">
                {isHindi ? "दवाइयाँ" : "Medicines"}
              </h4>
            </div>

            <div className="space-y-2">
              {medicines.map((medicine, index) => {
                const name =
                  typeof medicine === "string"
                    ? medicine
                    : medicine?.name ||
                      medicine?.medicine ||
                      medicine?.drug ||
                      `Medicine ${index + 1}`;

                const instructions =
                  typeof medicine === "object"
                    ? medicine?.instructions ||
                      medicine?.dose ||
                      medicine?.frequency ||
                      ""
                    : "";

                return (
                  <div
                    key={`${name}-${index}`}
                    className="rounded-xl border border-slate-200 bg-slate-50 p-2.5"
                  >
                    <p className="text-xs font-bold text-slate-900">
                      {index + 1}. {name}
                    </p>

                    {instructions && (
                      <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500">
                        {instructions}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {investigations.length > 0 && (
          <section className="mb-4">
            <h4 className="mb-2 text-xs font-bold text-slate-800">
              {isHindi ? "जाँच / परीक्षण" : "Investigations"}
            </h4>

            <div className="space-y-1.5">
              {investigations.map((item, index) => {
                const value =
                  typeof item === "string"
                    ? item
                    : item?.name ||
                      item?.test ||
                      item?.title ||
                      "Investigation";

                return (
                  <div
                    key={`${value}-${index}`}
                    className="rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-700"
                  >
                    {value}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {diagnosis && showFullDetails && (
          <section className="mb-4 rounded-xl border border-slate-200 bg-white p-3">
            <span className="block text-[9px] font-bold uppercase tracking-wider text-slate-400">
              {isHindi ? "नैदानिक जानकारी" : "Clinical information"}
            </span>
            <p className="mt-1 text-xs font-semibold leading-relaxed text-slate-800">
              {diagnosis}
            </p>
          </section>
        )}

        {notes && showFullDetails && (
          <section className="rounded-xl border border-slate-200 bg-slate-50 p-3">
            <span className="block text-[9px] font-bold uppercase tracking-wider text-slate-400">
              {isHindi ? "निर्देश / नोट्स" : "Instructions / Notes"}
            </span>
            <p className="mt-1 text-xs leading-relaxed text-slate-700">
              {notes}
            </p>
          </section>
        )}

        {!medicines.length &&
          !investigations.length &&
          !diagnosis &&
          !notes && (
            <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-center">
              <FileText className="mx-auto mb-2 h-7 w-7 text-slate-400" />
              <p className="text-xs font-semibold text-slate-600">
                {isHindi
                  ? "इस पूर्वावलोकन में विस्तृत जानकारी उपलब्ध नहीं है।"
                  : "Detailed information is not available in this preview."}
              </p>
            </div>
          )}
      </div>

      <div className="border-t border-slate-200 bg-slate-50 px-4 py-2.5">
        <div className="flex items-center justify-between gap-3">
          <span className="text-[10px] font-semibold text-slate-500">
            {getStatusLabel(status, isHindi)}
          </span>

          <span className="text-[9px] text-slate-400">
            {isHindi
              ? "दस्तावेज़ से प्राप्त जानकारी"
              : "Information from document"}
          </span>
        </div>
      </div>
    </div>
  );
};

export default DocumentPreview; 