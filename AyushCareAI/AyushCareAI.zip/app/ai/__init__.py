# AI provider abstraction layer
