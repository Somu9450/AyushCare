# AI prompt templates
